package com.music.musicproviderapi.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.music.musicproviderapi.config.ApplicationTestConfig;
import com.music.musicproviderapi.entity.Artist;
import com.music.musicproviderapi.repository.ArtistRepository;
import com.music.musicproviderapi.request.ArtistRequest;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.context.WebApplicationContext;


import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

/**
 * Unit Testcase Class  ArtistController
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(
        classes = {ApplicationTestConfig.class})
@WebAppConfiguration
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
public class ArtistControllerTest {

    @Autowired
    private WebApplicationContext webApplicationContext;

    public MockMvc mockMvc;

    @Autowired
    ArtistRepository artistRepository;

    @Before
    public void setUp() {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();
        createArtist();
    }

    private void createArtist() {
        Artist artistOne = Artist.builder().artistName("ArtistOne").build();
        artistRepository.saveAndFlush(artistOne);
        Artist artistTwo = Artist.builder().artistName("ArtistTwo").build();
        artistRepository.saveAndFlush(artistTwo);

    }

    @Test
    public void testToCreateArtist() throws Exception {
        ArtistRequest artistRequest = new ArtistRequest();
        artistRequest.setArtistName("nirvana");
        mockMvc.perform(post("/artists")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(artistRequest)))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().contentTypeCompatibleWith(MediaTypes.HAL_JSON_VALUE))
                .andExpect(jsonPath("$.artist", notNullValue()))
                .andExpect(jsonPath("$.artist.artistName", is("nirvana")));
    }

    @Test
    public void testToCreateArtist_WithInvalidRequest() throws Exception {
        ArtistRequest artistRequest = new ArtistRequest();
        artistRequest.setArtistName(null);
        MvcResult result = mockMvc.perform(post("/artists")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(artistRequest)))
                .andReturn();
        String content = result.getResponse().getContentAsString();
        Assert.assertTrue(content.contains("Enter a valid request"));
    }

    @Test
    public void testToUpdateArtist() throws Exception {
        Artist artist = Artist.builder().artistName("ArtistOne").build();
        artistRepository.saveAndFlush(artist);
        ArtistRequest artistRequest = new ArtistRequest();
        artistRequest.setArtistName("MyNewName");
        mockMvc.perform(put("/artists/{artistId}",artist.getArtistId().intValue())
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(artistRequest)))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().contentTypeCompatibleWith(MediaTypes.HAL_JSON_VALUE))
                .andExpect(jsonPath("$.artist", notNullValue()))
                .andExpect(jsonPath("$.artist.artistId", is(artist.getArtistId().intValue())))
                .andExpect(jsonPath("$.artist.artistName", is("MyNewName")));
    }

    @Test
    public void testToUpdateArtist_WithInvalidArtistId() throws Exception {
        ArtistRequest artistRequest = new ArtistRequest();
        artistRequest.setArtistName("MyNewName");
        MvcResult result = mockMvc.perform(put("/artists/0")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(artistRequest)))
                .andReturn();
        String content = result.getResponse().getContentAsString();
        Assert.assertTrue(content.contains("Enter a valid request"));
    }

    @Test
    public void testToGetArtistByArtistId() throws Exception {
        Artist artist = Artist.builder().artistName("ArtistOne").build();
        artistRepository.saveAndFlush(artist);
        mockMvc.perform(get("/artists/{artistId}",artist.getArtistId().intValue())
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().contentTypeCompatibleWith(MediaTypes.HAL_JSON_VALUE))
                .andExpect(jsonPath("$.artist", notNullValue()))
                .andExpect(jsonPath("$.artist.artistId", is(artist.getArtistId().intValue())))
                .andExpect(jsonPath("$.artist.artistName", is("ArtistOne")));
    }

    @Test
    public void testToGetArtistByArtistId_WithInvalidArtistId() throws Exception {
        MvcResult result = mockMvc.perform(get("/artists/0")
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andReturn();
        String content = result.getResponse().getContentAsString();
        Assert.assertTrue(content.contains("Enter a valid request"));
    }

    @Test
    public void testToGetAllArtists() throws Exception {
        mockMvc.perform(get("/artists")
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().contentTypeCompatibleWith(MediaTypes.HAL_JSON_VALUE))
                .andExpect(jsonPath("$.content", notNullValue()));
    }

    @Test
    public void testToGetAllArtists_WithArtistName() throws Exception {
        Artist artist = Artist.builder().artistName("Michel").build();
        artistRepository.saveAndFlush(artist);
        mockMvc.perform(get("/artists")
                .param("ArtistName", "Michel")
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().contentTypeCompatibleWith(MediaTypes.HAL_JSON_VALUE))
                .andExpect(jsonPath("$.content", notNullValue()))
                .andExpect(jsonPath("$.content[0].artist.artistName", is("Michel")))
                .andExpect(jsonPath("$.numberOfElements", is(1)));
    }

    private String getValueAsString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

}
