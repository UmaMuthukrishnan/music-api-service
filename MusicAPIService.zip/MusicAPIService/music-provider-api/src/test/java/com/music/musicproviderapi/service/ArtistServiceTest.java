package com.music.musicproviderapi.service;

import com.music.musicproviderapi.entity.Artist;
import com.music.musicproviderapi.exceptions.ArtistNotFoundException;
import com.music.musicproviderapi.model.ArtistModel;
import com.music.musicproviderapi.model.SortType;
import com.music.musicproviderapi.repository.ArtistRepository;

import com.music.musicproviderapi.repository.specifications.ArtistSpecification;
import com.music.musicproviderapi.request.ArtistRequest;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.mockito.Mockito;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.test.context.junit4.SpringRunner;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verifyNoMoreInteractions;

/**
 * Unit Testcase Class for ArtistService
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@RunWith(SpringRunner.class)
public class ArtistServiceTest {

    @InjectMocks
    ArtistService artistService;

    @Mock
    ArtistRepository artistRepository;

    private Root<Artist> root;
    private CriteriaQuery<?> cq;
    private CriteriaBuilder cb;

    @Before
    @SuppressWarnings("unchecked")
    public void setup() {


        this.root = (Root<Artist>) Mockito.mock(Root.class);
        this.cq = Mockito.mock(CriteriaQuery.class);
        this.cb = Mockito.mock(CriteriaBuilder.class);
    }

    @Test
    public void testToCreateNewArtist() {
        ArtistRequest artistRequest = new ArtistRequest();
        artistRequest.setArtistName("nirvana");
        Artist artist = Artist.builder().artistId(1L).artistName("nirvana").build();

        when(artistRepository.saveAndFlush(any())).thenReturn(artist);

        ArtistModel artistModel = artistService.createNewArtist(artistRequest);
        Artist createdArtist = artistModel.getArtist();
        Assert.assertNotNull(createdArtist);
        Assert.assertEquals(1, createdArtist.getArtistId().intValue());
        Assert.assertEquals("nirvana", createdArtist.getArtistName());
        Assert.assertNotNull(artistModel.getLinks());
    }

    @Test
    public void testToUpdateArtist() {
        ArtistRequest artistRequest = new ArtistRequest();
        artistRequest.setArtistName("nirvana-nevermind");
        Long artistId = 3L;
        Artist newArtist = Artist.builder().artistId(artistId).artistName("nirvana").build();

        when(artistRepository.saveAndFlush(any())).thenReturn(newArtist);
        when(artistRepository.findById(artistId)).thenReturn(Optional.of(newArtist));
        ArtistModel artistModel = artistService.updateArtist(artistId, artistRequest);
        Artist updatedArtist = artistModel.getArtist();
        Assert.assertNotNull(updatedArtist);
        Assert.assertEquals(3, updatedArtist.getArtistId().intValue());
        Assert.assertEquals("nirvana-nevermind", updatedArtist.getArtistName());
        Assert.assertNotNull(artistModel.getLinks());
    }

    @Test(expected = ArtistNotFoundException.class)
    public void testToUpdateArtist_withInvalid_ArtistId() {
        ArtistRequest artistRequest = new ArtistRequest();
        artistRequest.setArtistName("nirvana-nevermind");
        Long givenArtistId = 2L;
        when(artistRepository.findById(givenArtistId)).thenReturn(
                Optional.empty());
        artistService.updateArtist(givenArtistId, artistRequest);
    }

    @Test
    public void testToGetAnArtist() {
        Long artistId = 3L;
        Artist newArtist = Artist.builder().artistId(artistId).artistName("nirvana").build();

        when(artistRepository.saveAndFlush(any())).thenReturn(newArtist);
        when(artistRepository.findById(artistId)).thenReturn(Optional.of(newArtist));
        ArtistModel artistModel = artistService.getAnArtist(artistId);
        Artist retrievedArtist = artistModel.getArtist();
        Assert.assertNotNull(retrievedArtist);
        Assert.assertEquals(3, retrievedArtist.getArtistId().intValue());
        Assert.assertEquals("nirvana", retrievedArtist.getArtistName());
        Assert.assertNotNull(artistModel.getLinks());
    }

    @Test(expected = ArtistNotFoundException.class)
    public void testToGetAnArtist_WithInvalidArtistId() {
        Long artistId = 3L;
        Artist newArtist = Artist.builder().artistId(artistId).artistName("nirvana").build();

        when(artistRepository.saveAndFlush(any())).thenReturn(newArtist);
        when(artistRepository.findById(4L)).thenReturn(Optional.empty());
        artistService.getAnArtist(artistId);
    }

    @Test
    public void testToFindAllArtist() {
        Artist artistOne = Artist.builder().artistName("ArtistOne").build();
        when(artistRepository.saveAndFlush(any())).thenReturn(artistOne);
        when(artistRepository.findById(artistOne.getArtistId())).thenReturn(Optional.of(artistOne));
        Artist artistTwo = Artist.builder().artistName("ArtistTwo").build();
        when(artistRepository.saveAndFlush(any())).thenReturn(artistTwo);
        when(artistRepository.findById(artistTwo.getArtistId())).thenReturn(Optional.of(artistTwo));
        Artist artistThree = Artist.builder().artistName("ArtistThree").build();
        when(artistRepository.saveAndFlush(any())).thenReturn(artistThree);
        when(artistRepository.findById(artistThree.getArtistId())).thenReturn(Optional.of(artistThree));
        Artist artistFour = Artist.builder().artistName("nirvana").build();
        when(artistRepository.saveAndFlush(any())).thenReturn(artistFour);
        when(artistRepository.findById(artistFour.getArtistId())).thenReturn(Optional.of(artistFour));
        Artist artistFive = Artist.builder().artistName("FifthArtist").build();
        when(artistRepository.saveAndFlush(any())).thenReturn(artistFive);
        when(artistRepository.findById(artistFive.getArtistId())).thenReturn(Optional.of(artistFive));
        Pageable pageable = PageRequest.of(1, 20);
        final Specification<Artist> artistSpecification = ArtistSpecification.artistNameContainsIgnoreCase("artist");
        artistSpecification.toPredicate(this.root, this.cq, this.cb);
        List<Artist> artists = new ArrayList<>();
        artists.add(artistOne);
        artists.add(artistTwo);
        artists.add(artistThree);
        Page<Artist> artistPage = new PageImpl<>(artists);
        when(artistRepository.findAll(any(Specification.class), any(Pageable.class))).thenReturn(artistPage);
        Page<ArtistModel> artistModels = artistService.findAllArtist("artist", null, pageable);
        ArgumentCaptor<Pageable> pageArgument = ArgumentCaptor.forClass(Pageable.class);
        verify(artistRepository, times(1)).findAll(any(Specification.class), pageArgument.capture());
        verifyNoMoreInteractions(artistRepository);
        Pageable pageSpecification = pageArgument.getValue();
        Assert.assertNotNull(artistModels.getContent());
        Assert.assertEquals(3, artistModels.getContent().size());
        Artist artistModelOne = artistModels.getContent().get(0).getArtist();
        Artist artistModelTwo = artistModels.getContent().get(1).getArtist();
        Assert.assertEquals(1, pageSpecification.getPageNumber());
        Assert.assertEquals("ArtistOne", artistModelOne.getArtistName());
        Assert.assertEquals("ArtistTwo", artistModelTwo.getArtistName());
    }

    @Test
    public void testToFindAllArtist_sortByArtistName() {
        Artist artistOne = Artist.builder().artistName("ArtistOne").build();
        when(artistRepository.saveAndFlush(any())).thenReturn(artistOne);
        when(artistRepository.findById(artistOne.getArtistId())).thenReturn(Optional.of(artistOne));
        Artist artistTwo = Artist.builder().artistName("ArtistTwo").build();
        when(artistRepository.saveAndFlush(any())).thenReturn(artistTwo);
        when(artistRepository.findById(artistTwo.getArtistId())).thenReturn(Optional.of(artistTwo));

        Pageable pageable = PageRequest.of(1, 20);
        final Specification<Artist> artistSpecification = ArtistSpecification.artistNameContainsIgnoreCase("artist");
        artistSpecification.toPredicate(this.root, this.cq, this.cb);
        List<Artist> artists = new ArrayList<>();
        artists.add(artistOne);
        artists.add(artistTwo);

        Page<Artist> artistPage = new PageImpl<>(artists);
        when(artistRepository.findAll(any(Specification.class), any(Pageable.class))).thenReturn(artistPage);
        Page<ArtistModel> artistModels = artistService.findAllArtist("artist", SortType.ASC, pageable);
        ArgumentCaptor<Pageable> pageArgument = ArgumentCaptor.forClass(Pageable.class);
        verify(artistRepository, times(1)).findAll(any(Specification.class), pageArgument.capture());
        verifyNoMoreInteractions(artistRepository);
        Pageable pageSpecification = pageArgument.getValue();
        Assert.assertNotNull(artistModels.getContent());
        Assert.assertEquals(2, artistModels.getContent().size());
        Artist artistModelOne = artistModels.getContent().get(0).getArtist();
        Artist artistModelTwo = artistModels.getContent().get(1).getArtist();
        Assert.assertEquals(1, pageSpecification.getPageNumber());
        Assert.assertTrue(pageSpecification.getSort().isSorted());
        Assert.assertEquals(Sort.Direction.ASC, pageSpecification.getSort().getOrderFor("artistName").getDirection());
        Assert.assertEquals("ArtistOne", artistModelOne.getArtistName());
        Assert.assertEquals("ArtistTwo", artistModelTwo.getArtistName());
    }

}


