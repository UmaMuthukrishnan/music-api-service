package com.music.musicproviderapi.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.music.musicproviderapi.config.ApplicationTestConfig;
import com.music.musicproviderapi.entity.Album;
import com.music.musicproviderapi.entity.Artist;
import com.music.musicproviderapi.entity.Genre;
import com.music.musicproviderapi.model.Track;
import com.music.musicproviderapi.repository.AlbumRepository;
import com.music.musicproviderapi.repository.ArtistRepository;
import com.music.musicproviderapi.request.AlbumRequest;
import com.music.musicproviderapi.response.AlbumTrackList;
import com.music.musicproviderapi.response.AlbumTrackResponse;
import com.music.musicproviderapi.serviceClient.DiscogsAPIServiceClient;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import org.springframework.web.context.WebApplicationContext;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

/**
 * Unit Testcase Class  AlbumController
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(
        classes = {ApplicationTestConfig.class})
@WebAppConfiguration
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
public class AlbumControllerTest {
    @Autowired
    private WebApplicationContext webApplicationContext;

    public MockMvc mockMvc;

    @Autowired
    AlbumRepository albumRepository;

    @Autowired
    ArtistRepository artistRepository;

    @MockBean
    DiscogsAPIServiceClient discogsAPIServiceClient;

    @Before
    public void setUp() {

        this.mockMvc = webAppContextSetup(webApplicationContext).build();
        createAlbumForArtist();
    }

    private void createAlbumForArtist() {
        List<Genre> genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("Rock").build());
        genreList.add(Genre.builder().genreName("Melody").build());
        Long artistId = 1L;
        Artist newArtist = Artist.builder().artistId(artistId).artistName("nirvana").build();
        artistRepository.saveAndFlush(newArtist);
        Album newAlbum = Album.builder()
                .albumId(1L)
                .albumName("nevermind")
                .artist(newArtist)
                .genres(genreList)
                .releaseYear(2020)
                .build();
        albumRepository.saveAndFlush(newAlbum);
    }

    @Test
    public void testToGetAllArtistAlbums() throws Exception {
        mockMvc.perform(get("/artists/1/albums")
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().contentTypeCompatibleWith(MediaTypes.HAL_JSON_VALUE))
                .andExpect(jsonPath("$.content", notNullValue()))
                .andExpect(jsonPath("$.content[0].album.albumName", is("nevermind")))
                .andExpect(jsonPath("$.content[0].album.genres", notNullValue()))
                .andExpect(jsonPath("$.content[0].album.genres[0].genreName", is("Rock")))
                .andExpect(jsonPath("$.content[0].album.genres[1].genreName", is("Melody")));
    }

    @Test
    public void testToGetAllArtistAlbums_WithInvalidArtistId() throws Exception {
        MvcResult result = mockMvc.perform(get("/artists/0/albums")
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andReturn();
        String content = result.getResponse().getContentAsString();
        Assert.assertTrue(content.contains("Enter a valid request"));
    }

    @Test
    public void testToAddNewAlbumForArtist() throws Exception {
        AlbumRequest albumRequest = new AlbumRequest();
        albumRequest.setAlbumName("My New Album");
        albumRequest.setReleaseYear("2020");
        List<Genre> genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("NewHits").build());
        albumRequest.setGenres(genreList);
        mockMvc.perform(post("/artists/1/albums")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(albumRequest)))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().contentTypeCompatibleWith(MediaTypes.HAL_JSON_VALUE))
                .andExpect(jsonPath("$.album", notNullValue()))
                .andExpect(jsonPath("$.album.albumId", is(2)))
                .andExpect(jsonPath("$.album.albumName", is("My New Album")))
                .andExpect(jsonPath("$.album.genres", notNullValue()))
                .andExpect(jsonPath("$.album.genres[0].genreName", is("NewHits")));

    }

    @Test
    public void testToAddNewAlbumForArtist_withInvalidArtistId() throws Exception {
        AlbumRequest albumRequest = new AlbumRequest();
        albumRequest.setAlbumName("My New Album");
        albumRequest.setReleaseYear("2020");
        List<Genre> genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("NewHits").build());
        albumRequest.setGenres(genreList);
        MvcResult result = mockMvc.perform(post("/artists/0/albums")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(albumRequest)))
                .andReturn();
        String content = result.getResponse().getContentAsString();
        Assert.assertTrue(content.contains("Enter a valid request"));

    }

    @Test
    public void testToUpdateAlbumForArtist() throws Exception {
        AlbumRequest albumRequest = new AlbumRequest();
        albumRequest.setAlbumName("My Updated Album");
        List<Genre> genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("Rock-Style").build());
        albumRequest.setGenres(genreList);
        mockMvc.perform(put("/artists/1/albums/1")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(albumRequest)))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().contentTypeCompatibleWith(MediaTypes.HAL_JSON_VALUE))
                .andExpect(jsonPath("$.album", notNullValue()))
                .andExpect(jsonPath("$.album.albumName", is("My Updated Album")))
                .andExpect(jsonPath("$.album.genres", notNullValue()))
                .andExpect(jsonPath("$.album.albumId", is(1)))
                .andExpect(jsonPath("$.album.genres[0].genreName", is("Rock")))
                .andExpect(jsonPath("$.album.genres[1].genreName", is("Melody")))
                .andExpect(jsonPath("$.album.genres[2].genreName", is("Rock-Style")));

    }

    @Test
    public void testToUpdateAlbumForArtist_withInvalidArtistId() throws Exception {
        AlbumRequest albumRequest = new AlbumRequest();
        albumRequest.setAlbumName("My Updated Album");
        List<Genre> genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("Rock-Style").build());
        albumRequest.setGenres(genreList);
        MvcResult result = mockMvc.perform(put("/artists/0/albums/1")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(albumRequest)))
                .andReturn();
        String content = result.getResponse().getContentAsString();
        Assert.assertTrue(content.contains("Enter a valid request"));

    }

    @Test
    public void testToUpdateAlbumForArtist_withInvalidAlbumId() throws Exception {
        AlbumRequest albumRequest = new AlbumRequest();
        albumRequest.setAlbumName("My Updated Album");
        List<Genre> genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("Rock-Style").build());
        albumRequest.setGenres(genreList);
        MvcResult result = mockMvc.perform(put("/artists/1/albums/0")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(albumRequest)))
                .andReturn();
        String content = result.getResponse().getContentAsString();
        Assert.assertTrue(content.contains("Enter a valid request"));

    }

    @Test
    public void testToGetAlbumDetailsOfAnArtist() throws Exception {
        AlbumTrackList albumTrackList = getMockDataforDiscogsAPI();
        when(discogsAPIServiceClient.getArtistAlbumTracks(anyString(), anyString())).thenReturn(albumTrackList);
        mockMvc.perform(get("/artists/1/albums/1")
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().contentTypeCompatibleWith(MediaTypes.HAL_JSON_VALUE))
                .andExpect(jsonPath("$.artistName", is("nirvana")))
                .andExpect(jsonPath("$.albumName", is("nevermind")))
                .andExpect(jsonPath("$.albumTrackList", notNullValue()))
                .andExpect(jsonPath("$.albumTrackList.albumTrackResponseList", notNullValue()))
                .andExpect(jsonPath("$.albumTrackList.albumTrackResponseList[0].title", is("FirstTitle")))
                .andExpect(jsonPath("$.albumTrackList.albumTrackResponseList[0].resourceUrl", is("http://new1")))
                .andExpect(jsonPath("$.albumTrackList.albumTrackResponseList[0].trackList[0].trackTitle", is("FirstTrack")));
    }

    @Test
    public void testToGetAlbumDetailsOfAnArtist_WithInvalidArtistId() throws Exception {
        MvcResult result = mockMvc.perform(get("/artists/0/albums/1")
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andReturn();
        String content = result.getResponse().getContentAsString();
        Assert.assertTrue(content.contains("Enter a valid request"));
    }

    @Test
    public void testToGetAlbumDetailsOfAnArtist_WithInvalidAlbumId() throws Exception {
        MvcResult result = mockMvc.perform(get("/artists/1/albums/0")
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andReturn();
        String content = result.getResponse().getContentAsString();
        Assert.assertTrue(content.contains("Enter a valid request"));
    }

    private AlbumTrackList getMockDataforDiscogsAPI() {
        List<AlbumTrackResponse> albumTrackResponseList = new ArrayList<>();
        List<Track> trackListOne = Arrays.asList(
                Track.builder().trackNumber("1").trackTitle("FirstTrack").build(),
                Track.builder().trackNumber("2").trackTitle("SecondTrack").build());
        List<Track> trackListTwo = Arrays.asList(
                Track.builder().trackNumber("1").trackTitle("Track1").build(),
                Track.builder().trackNumber("2").trackTitle("Track2").build());
        AlbumTrackResponse albumTrackResponseOne = AlbumTrackResponse.builder()
                .title("FirstTitle")
                .trackList(trackListOne)
                .resourceUrl("http://new1")
                .build();
        AlbumTrackResponse albumTrackResponseTwo = AlbumTrackResponse.builder()
                .title("SecondTitle")
                .trackList(trackListTwo)
                .resourceUrl("http://new2")
                .build();
        albumTrackResponseList.add(albumTrackResponseOne);
        albumTrackResponseList.add(albumTrackResponseTwo);
        return AlbumTrackList.builder()
                .albumTrackResponseList(albumTrackResponseList).build();
    }

    private String getValueAsString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }
}
