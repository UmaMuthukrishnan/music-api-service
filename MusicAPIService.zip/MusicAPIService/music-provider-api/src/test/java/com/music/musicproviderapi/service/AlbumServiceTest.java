package com.music.musicproviderapi.service;

import com.music.musicproviderapi.entity.*;
import com.music.musicproviderapi.exceptions.AlbumNotFoundException;
import com.music.musicproviderapi.exceptions.ArtistNotFoundException;
import com.music.musicproviderapi.model.AlbumModel;
import com.music.musicproviderapi.model.SortType;
import com.music.musicproviderapi.model.Track;
import com.music.musicproviderapi.repository.AlbumRepository;
import com.music.musicproviderapi.repository.ArtistRepository;
import com.music.musicproviderapi.repository.specifications.ArtistAlbumSpecification;
import com.music.musicproviderapi.request.AlbumRequest;
import com.music.musicproviderapi.response.AlbumTrackList;
import com.music.musicproviderapi.response.AlbumTrackResponse;
import com.music.musicproviderapi.response.ArtistAlbumTrackResponse;
import com.music.musicproviderapi.serviceClient.DiscogsAPIServiceClient;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.test.context.junit4.SpringRunner;

import javax.persistence.criteria.*;
import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit Testcase Class for AlbumService
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@RunWith(SpringRunner.class)
public class AlbumServiceTest {

    @InjectMocks
    AlbumService albumService;

    @Mock
    AlbumRepository albumRepository;

    @Mock
    ArtistRepository artistRepository;

    @Mock
    DiscogsAPIServiceClient discogsAPIServiceClient;


    private Root<Album> root;
    private CriteriaQuery<?> cq;
    private CriteriaBuilder cb;


    @Before
    @SuppressWarnings("unchecked")
    public void setup() {


        this.root = (Root<Album>) Mockito.mock(Root.class);
        this.cq = Mockito.mock(CriteriaQuery.class);
        this.cb = Mockito.mock(CriteriaBuilder.class);
    }

    @Test
    public void testToCreateNewArtistAlbum() {
        AlbumRequest albumRequest = new AlbumRequest();
        albumRequest.setAlbumName("My Album");
        albumRequest.setReleaseYear("2020");
        List<Genre> genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("Rock").build());
        genreList.add(Genre.builder().genreName("Melody").build());
        albumRequest.setGenres(genreList);
        Long artistId = 3L;
        Artist newArtist = Artist.builder().artistId(artistId).artistName("nirvana").build();
        when(artistRepository.saveAndFlush(any())).thenReturn(newArtist);
        Album newAlbum = Album.builder()
                .albumId(1L)
                .albumName("My Album")
                .artist(newArtist)
                .genres(genreList)
                .releaseYear(2020)
                .build();


        when(artistRepository.findById(artistId)).thenReturn(Optional.of(newArtist));
        when(albumRepository.saveAndFlush(any())).thenReturn(newAlbum);

        AlbumModel albumModel = albumService.createNewAlbumForAnArtist(artistId, albumRequest);
        Album album = albumModel.getAlbum();
        Artist albumArtist = album.getArtist();

        Assert.assertNotNull(album);
        Assert.assertEquals(1, album.getAlbumId().intValue());
        Assert.assertEquals(3, albumArtist.getArtistId().intValue());
        Assert.assertEquals("nirvana", albumArtist.getArtistName());
        Assert.assertEquals("My Album", album.getAlbumName());
        Assert.assertEquals(2020, album.getReleaseYear().intValue());
        Assert.assertEquals(2, album.getGenres().size());
        Assert.assertNotNull(albumModel.getLinks());
    }


    @Test(expected = ArtistNotFoundException.class)
    public void testToCreateNewArtistAlbum_withInvalid_ArtistId() {
        AlbumRequest albumRequest = new AlbumRequest();
        albumRequest.setAlbumName("My Album");
        albumRequest.setReleaseYear("2020");
        List<Genre> genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("Rock").build());
        genreList.add(Genre.builder().genreName("Melody").build());
        albumRequest.setGenres(genreList);
        Long artistId = 3L;
        Artist newArtist = Artist.builder().artistId(artistId).artistName("nirvana").build();
        when(artistRepository.saveAndFlush(any())).thenReturn(newArtist);
        Album newAlbum = Album.builder()
                .albumId(1L)
                .albumName("My Album")
                .artist(newArtist)
                .genres(genreList)
                .releaseYear(2020)
                .build();

        when(artistRepository.findById(artistId)).thenReturn(Optional.empty());
        when(albumRepository.saveAndFlush(any())).thenReturn(newAlbum);
        albumService.createNewAlbumForAnArtist(artistId, albumRequest);
    }

    @Test
    public void testToUpdateArtistAlbum() {
        AlbumRequest albumRequest = new AlbumRequest();
        albumRequest.setAlbumName("Updated Album");
        albumRequest.setReleaseYear("2020");
        List<Genre> genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("Rock").build());
        genreList.add(Genre.builder().genreName("Melody").build());
        albumRequest.setGenres(genreList);
        Long artistId = 3L;
        Long albumId = 1L;
        Artist newArtist = Artist.builder().artistId(artistId).artistName("nirvana").build();
        when(artistRepository.existsById(artistId)).thenReturn(true);
        genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("OldTrack").build());
        Album newAlbum = Album.builder()
                .albumId(1L)
                .albumName("My Album")
                .artist(newArtist)
                .genres(genreList)
                .releaseYear(2018)
                .build();

        when(albumRepository.saveAndFlush(any())).thenReturn(newAlbum);
        when(albumRepository.findById(albumId)).thenReturn(Optional.of(newAlbum));
        AlbumModel albumModel = albumService.updateAlbumForArtist(artistId, albumId, albumRequest);
        Album album = albumModel.getAlbum();
        Artist albumArtist = album.getArtist();

        Assert.assertNotNull(album);
        Assert.assertEquals(1, album.getAlbumId().intValue());
        Assert.assertEquals(3, albumArtist.getArtistId().intValue());
        Assert.assertEquals("nirvana", albumArtist.getArtistName());
        Assert.assertEquals("Updated Album", album.getAlbumName());
        Assert.assertEquals(2020, album.getReleaseYear().intValue());
        Assert.assertEquals(3, album.getGenres().size());
        Assert.assertNotNull(albumModel.getLinks());
    }

    @Test(expected = ArtistNotFoundException.class)
    public void testToUpdateArtistAlbum_withInvalid_ArtistId() {
        AlbumRequest albumRequest = new AlbumRequest();
        albumRequest.setAlbumName("Updated Album");
        albumRequest.setReleaseYear("2020");
        List<Genre> genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("Rock").build());
        genreList.add(Genre.builder().genreName("Melody").build());
        genreList.add(Genre.builder().genreName("Solo Track").build());
        albumRequest.setGenres(genreList);
        Long artistId = 3L;
        Long albumId = 1L;
        when(artistRepository.existsById(artistId)).thenReturn(false);
        albumService.updateAlbumForArtist(artistId, albumId, albumRequest);
    }

    @Test(expected = AlbumNotFoundException.class)
    public void testToUpdateArtistAlbum_withInvalid_AlbumId() {
        AlbumRequest albumRequest = new AlbumRequest();
        albumRequest.setAlbumName("Updated Album");
        albumRequest.setReleaseYear("2020");
        List<Genre> genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("Rock").build());
        genreList.add(Genre.builder().genreName("Melody").build());
        genreList.add(Genre.builder().genreName("Solo Track").build());
        albumRequest.setGenres(genreList);
        Long artistId = 3L;
        Long givenAlbumId = 1L;
        when(artistRepository.existsById(artistId)).thenReturn(true);
        when(albumRepository.findById(givenAlbumId)).thenReturn(Optional.empty());
        albumService.updateAlbumForArtist(artistId, givenAlbumId, albumRequest);
    }

    @Test
    public void testToGetAllAlbumsByArtist() {
        Long artistId = 1L;
        Artist artist = Artist.builder().artistId(artistId).artistName("nirvana").build();
        when(artistRepository.existsById(artistId)).thenReturn(true);
        List<Genre> genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("Rock").build());
        genreList.add(Genre.builder().genreName("Melody").build());
        Album albumOne = Album.builder()
                .albumId(1L)
                .albumName("My First Album")
                .artist(artist)
                .genres(genreList)
                .releaseYear(2020)
                .build();
        genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("Non-Music").build());
        Album albumTwo = Album.builder()
                .albumId(2L)
                .albumName("My Second Album")
                .artist(artist)
                .genres(genreList)
                .releaseYear(2018)
                .build();
        List<Album> albums = new ArrayList<>();
        albums.add(albumOne);
        albums.add(albumTwo);
        Pageable pageable = PageRequest.of(1, 20);
        Page<Album> albumPage = new PageImpl<>(albums);
        when(artistRepository.findById(artistId)).thenReturn(Optional.of(artist));
        final Specification<Album> albumSpecification = ArtistAlbumSpecification.findByArtistId(1L);
        albumSpecification.toPredicate(this.root, this.cq, this.cb);
        Mockito.verify(this.cb, Mockito.times(1)).equal(this.root.get(Album_.ARTIST), artistId);
        when(albumRepository.findAll(any(Specification.class), any(Pageable.class))).thenReturn(albumPage);
        Page<AlbumModel> albumModels = albumService.getAllAlbumsByArtist(artistId, null, null, null, pageable);
        ArgumentCaptor<Pageable> pageArgument = ArgumentCaptor.forClass(Pageable.class);
        ArgumentCaptor<Page<AlbumModel>> page = ArgumentCaptor.forClass(Page.class);
        verify(albumRepository, times(1)).findAll(any(Specification.class), pageArgument.capture());
        verifyNoMoreInteractions(albumRepository);
        Pageable pageSpecification = pageArgument.getValue();
        Assert.assertNotNull(albumModels.getContent());
        Assert.assertEquals(2, albumModels.getContent().size());
        Album albumModelOne = albumModels.getContent().get(0).getAlbum();
        Album albumModelTwo = albumModels.getContent().get(1).getAlbum();
        Assert.assertEquals(1, pageSpecification.getPageNumber());
        Assert.assertEquals("My First Album", albumModelOne.getAlbumName());
        Assert.assertEquals("My Second Album", albumModelTwo.getAlbumName());
        Assert.assertEquals(1, albumModelOne.getArtist().getArtistId().intValue());
        Assert.assertEquals(1, albumModelTwo.getArtist().getArtistId().intValue());
        Assert.assertEquals(1, albumModelOne.getAlbumId().intValue());
        Assert.assertEquals(2, albumModelTwo.getAlbumId().intValue());
        Assert.assertEquals("nirvana", albumModelTwo.getArtist().getArtistName());
        Assert.assertEquals(2020, albumModelOne.getReleaseYear().intValue());
        Assert.assertEquals(2018, albumModelTwo.getReleaseYear().intValue());
        Assert.assertEquals(2, albumModelOne.getGenres().size());
        Assert.assertEquals(1, albumModelTwo.getGenres().size());

    }

    @Test
    public void testToGetAllAlbumsByArtist_SortByAlbum() {
        Long artistId = 1L;
        Artist artist = Artist.builder().artistId(artistId).artistName("nirvana").build();
        when(artistRepository.existsById(artistId)).thenReturn(true);
        List<Genre> genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("Rock").build());
        genreList.add(Genre.builder().genreName("Melody").build());
        Album albumOne = Album.builder()
                .albumId(1L)
                .albumName("Album1")
                .artist(artist)
                .genres(genreList)
                .releaseYear(2020)
                .build();
        genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("Non-Music").build());
        Album albumTwo = Album.builder()
                .albumId(2L)
                .albumName("Album2")
                .artist(artist)
                .genres(genreList)
                .releaseYear(2018)
                .build();
        List<Album> albums = new ArrayList<>();
        albums.add(albumOne);
        albums.add(albumTwo);
        Pageable pageable = PageRequest.of(1, 20);
        Page<Album> albumPage = new PageImpl<>(albums);
        when(artistRepository.findById(artistId)).thenReturn(Optional.of(artist));
        final Specification<Album> albumSpecification = ArtistAlbumSpecification.findByArtistId(1L);
        albumSpecification.toPredicate(this.root, this.cq, this.cb);
        Mockito.verify(this.cb, Mockito.times(1)).equal(this.root.get(Album_.ARTIST), artistId);
        when(albumRepository.findAll(any(Specification.class), any(Pageable.class))).thenReturn(albumPage);
        Page<AlbumModel> albumModels = albumService.getAllAlbumsByArtist(artistId, SortType.ASC, null, null, pageable);
        ArgumentCaptor<Pageable> pageArgument = ArgumentCaptor.forClass(Pageable.class);
        verify(albumRepository, times(1)).findAll(any(Specification.class), pageArgument.capture());
        verifyNoMoreInteractions(albumRepository);
        Pageable pageSpecification = pageArgument.getValue();
        Assert.assertNotNull(albumModels.getContent());
        Assert.assertEquals(2, albumModels.getContent().size());
        Album albumModelOne = albumModels.getContent().get(0).getAlbum();
        Album albumModelTwo = albumModels.getContent().get(1).getAlbum();
        Assert.assertEquals(1, pageSpecification.getPageNumber());
        Assert.assertTrue(pageSpecification.getSort().isSorted());
        Assert.assertEquals(Sort.Direction.ASC, pageSpecification.getSort().getOrderFor("albumName").getDirection());
        Assert.assertEquals("Album1", albumModelOne.getAlbumName());
        Assert.assertEquals("Album2", albumModelTwo.getAlbumName());
        Assert.assertEquals(1, albumModelOne.getArtist().getArtistId().intValue());
        Assert.assertEquals(1, albumModelTwo.getArtist().getArtistId().intValue());
        Assert.assertEquals(1, albumModelOne.getAlbumId().intValue());
        Assert.assertEquals(2, albumModelTwo.getAlbumId().intValue());
        Assert.assertEquals("nirvana", albumModelTwo.getArtist().getArtistName());
        Assert.assertEquals(2020, albumModelOne.getReleaseYear().intValue());
        Assert.assertEquals(2018, albumModelTwo.getReleaseYear().intValue());
        Assert.assertEquals(2, albumModelOne.getGenres().size());
        Assert.assertEquals(1, albumModelTwo.getGenres().size());

    }

    @Test
    public void testToGetAllAlbumsByArtist_sortByReleaseYear() {
        Long artistId = 1L;
        Artist artist = Artist.builder().artistId(artistId).artistName("nirvana").build();
        when(artistRepository.existsById(artistId)).thenReturn(true);
        List<Genre> genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("Rock").build());
        genreList.add(Genre.builder().genreName("Melody").build());
        Album albumOne = Album.builder()
                .albumId(1L)
                .albumName("Album1")
                .artist(artist)
                .genres(genreList)
                .releaseYear(2018)
                .build();
        genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("Non-Music").build());
        Album albumTwo = Album.builder()
                .albumId(2L)
                .albumName("Album2")
                .artist(artist)
                .genres(genreList)
                .releaseYear(2020)
                .build();
        List<Album> albums = new ArrayList<>();
        albums.add(albumOne);
        albums.add(albumTwo);
        Pageable pageable = PageRequest.of(1, 20);
        Page<Album> albumPage = new PageImpl<>(albums);
        when(artistRepository.findById(artistId)).thenReturn(Optional.of(artist));
        final Specification<Album> albumSpecification = ArtistAlbumSpecification.findByArtistId(1L);
        albumSpecification.toPredicate(this.root, this.cq, this.cb);
        Mockito.verify(this.cb, Mockito.times(1)).equal(this.root.get(Album_.ARTIST), artistId);
        when(albumRepository.findAll(any(Specification.class), any(Pageable.class))).thenReturn(albumPage);
        Page<AlbumModel> albumModels = albumService.getAllAlbumsByArtist(artistId, null, SortType.ASC, null, pageable);
        ArgumentCaptor<Pageable> pageArgument = ArgumentCaptor.forClass(Pageable.class);
        verify(albumRepository, times(1)).findAll(any(Specification.class), pageArgument.capture());
        verifyNoMoreInteractions(albumRepository);
        Pageable pageSpecification = pageArgument.getValue();
        Assert.assertNotNull(albumModels.getContent());
        Assert.assertEquals(2, albumModels.getContent().size());
        Album albumModelOne = albumModels.getContent().get(0).getAlbum();
        Album albumModelTwo = albumModels.getContent().get(1).getAlbum();
        Assert.assertEquals(1, pageSpecification.getPageNumber());
        Assert.assertTrue(pageSpecification.getSort().isSorted());
        Assert.assertEquals(Sort.Direction.ASC, pageSpecification.getSort().getOrderFor("releaseYear").getDirection());
        Assert.assertEquals("Album1", albumModelOne.getAlbumName());
        Assert.assertEquals("Album2", albumModelTwo.getAlbumName());
        Assert.assertEquals(1, albumModelOne.getArtist().getArtistId().intValue());
        Assert.assertEquals(1, albumModelTwo.getArtist().getArtistId().intValue());
        Assert.assertEquals(1, albumModelOne.getAlbumId().intValue());
        Assert.assertEquals(2, albumModelTwo.getAlbumId().intValue());
        Assert.assertEquals("nirvana", albumModelTwo.getArtist().getArtistName());
        Assert.assertEquals(2018, albumModelOne.getReleaseYear().intValue());
        Assert.assertEquals(2020, albumModelTwo.getReleaseYear().intValue());
        Assert.assertEquals(2, albumModelOne.getGenres().size());
        Assert.assertEquals(1, albumModelTwo.getGenres().size());

    }

    @Test(expected = ArtistNotFoundException.class)
    public void testToGetAllAlbumsByArtist_WithInvalidArtistID() {
        Long artistId = 100L;
        Artist artist = Artist.builder().artistId(1L).artistName("nirvana").build();
        when(artistRepository.findById(1L)).thenReturn(Optional.of(artist));
        when(artistRepository.existsById(artistId)).thenReturn(false);
        albumService.getAllAlbumsByArtist(artistId, null, null, null, any(Pageable.class));
    }

    @Test
    public void testToGetAlbumDetailsOfAnArtist() {
        Long artistId = 1L;
        Long albumId = 2L;
        Artist newArtist = Artist.builder().artistId(artistId).artistName("nirvana").build();
        when(artistRepository.saveAndFlush(any())).thenReturn(newArtist);
        when(artistRepository.findById(artistId)).thenReturn(Optional.of(newArtist));
        List<Genre> genreList = new ArrayList<>();
        genreList.add(Genre.builder().genreName("Rock").build());
        genreList.add(Genre.builder().genreName("Melody").build());
        Album newAlbum = Album.builder()
                .albumId(2L)
                .albumName("My Album")
                .artist(newArtist)
                .genres(genreList)
                .releaseYear(2018)
                .build();

        when(albumRepository.saveAndFlush(any())).thenReturn(newAlbum);
        when(albumRepository.findById(albumId)).thenReturn(Optional.of(newAlbum));

        List<AlbumTrackResponse> albumTrackResponseList = new ArrayList<>();
        List<Track> trackListOne = Arrays.asList(
                Track.builder().trackNumber("1").trackTitle("FirstTrack").build(),
                Track.builder().trackNumber("2").trackTitle("SecondTrack").build());
        List<Track> trackListTwo = Arrays.asList(
                Track.builder().trackNumber("1").trackTitle("Track1").build(),
                Track.builder().trackNumber("2").trackTitle("Track2").build());
        AlbumTrackResponse albumTrackResponseOne = AlbumTrackResponse.builder()
                .title("FirstTitle")
                .trackList(trackListOne)
                .resourceUrl("http://new1")
                .build();
        AlbumTrackResponse albumTrackResponseTwo = AlbumTrackResponse.builder()
                .title("SecondTitle")
                .trackList(trackListTwo)
                .resourceUrl("http://new2")
                .build();
        albumTrackResponseList.add(albumTrackResponseOne);
        albumTrackResponseList.add(albumTrackResponseTwo);
        AlbumTrackList albumTrackList = AlbumTrackList.builder()
                .albumTrackResponseList(albumTrackResponseList).build();
        when(discogsAPIServiceClient.getArtistAlbumTracks(anyString(), anyString())).thenReturn(albumTrackList);
        ArtistAlbumTrackResponse artistAlbumTrackResponse = albumService.getAlbumDetailsOfAnArtist(artistId, albumId);
        AlbumTrackList albumTrackListResponse = artistAlbumTrackResponse.getAlbumTrackList();
        AlbumTrackResponse albumTrackOne = albumTrackListResponse.getAlbumTrackResponseList().get(0);
        AlbumTrackResponse albumTrackTwo = albumTrackListResponse.getAlbumTrackResponseList().get(1);
        Assert.assertEquals("My Album", artistAlbumTrackResponse.getAlbumName());
        Assert.assertNotNull(albumTrackListResponse);
        Assert.assertEquals(2, albumTrackListResponse.getAlbumTrackResponseList().size());
        Assert.assertEquals("FirstTitle", albumTrackOne.getTitle());
        Assert.assertEquals(2, albumTrackOne.getTrackList().size());
        Assert.assertEquals("FirstTrack", albumTrackOne.getTrackList().get(0).getTrackTitle());
        Assert.assertEquals("SecondTrack", albumTrackOne.getTrackList().get(1).getTrackTitle());
        Assert.assertEquals("http://new1", albumTrackOne.getResourceUrl());
        Assert.assertEquals("SecondTitle", albumTrackTwo.getTitle());
        Assert.assertEquals(2, albumTrackTwo.getTrackList().size());
        Assert.assertEquals("Track1", albumTrackTwo.getTrackList().get(0).getTrackTitle());
        Assert.assertEquals("Track2", albumTrackTwo.getTrackList().get(1).getTrackTitle());
        Assert.assertEquals("http://new2", albumTrackTwo.getResourceUrl());
    }

    @Test(expected = ArtistNotFoundException.class)
    public void testToGetAlbumDetailsOfAnArtist_WithInvalidArtist() {
        Long givenArtistId = 100L;
        Long albumId = 2L;
        when(artistRepository.findById(1L)).thenReturn(Optional.empty());
        albumService.getAlbumDetailsOfAnArtist(givenArtistId, albumId);

    }

    @Test(expected = AlbumNotFoundException.class)
    public void testToGetAlbumDetailsOfAnArtist_WithInvalidAlbum() {
        Long givenArtistId = 1L;
        Long albumId = 100L;
        Artist artist = Artist.builder()
                .artistId(givenArtistId).artistName("nirvana").build();
        when(artistRepository.findById(1L)).thenReturn(Optional.of(artist));
        when(albumRepository.findById(100L)).thenReturn(Optional.empty());
        albumService.getAlbumDetailsOfAnArtist(givenArtistId, albumId);

    }
}
