package com.music.musicproviderapi;

import com.music.musicproviderapi.controller.ArtistControllerTest;
import com.music.musicproviderapi.service.AlbumServiceTest;
import com.music.musicproviderapi.service.ArtistServiceTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
/**
 * Common class to run all the test cases in ArtistControllerTest.class,ArtistServiceTest.class, AlbumServiceTest.class
 *
 * @author Uma Muthukrishnan
 * @version 1.0
 *
 * Commented to avoid re-running again while doing maven build
 */
//@RunWith(Suite.class)
//@Suite.SuiteClasses({ArtistControllerTest.class,ArtistServiceTest.class, AlbumServiceTest.class})
public class MusicProviderApiApplicationTests {
}
