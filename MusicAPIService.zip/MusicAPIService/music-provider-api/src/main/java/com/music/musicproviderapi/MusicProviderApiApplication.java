package com.music.musicproviderapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

/**
 * Main class for MusicProviderApi (Registered in Eureka Naming server as "MUSIC-PROVIDER-SERVICE")
 * <p>
 * Consumer of DiscogsAPI provider(Registered in Eureka Naming server as "DISCOGS-INFORMATION-SERVICE")
 * <p>
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@SpringBootApplication
@EnableEurekaClient
public class MusicProviderApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(MusicProviderApiApplication.class, args);
    }

}
