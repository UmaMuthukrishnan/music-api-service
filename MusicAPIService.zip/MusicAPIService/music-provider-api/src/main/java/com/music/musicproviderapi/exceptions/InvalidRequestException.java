package com.music.musicproviderapi.exceptions;


import com.music.musicproviderapi.model.MusicApiError;
import lombok.Getter;


/**
 * InvalidRequestException Exception for the API
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
public class InvalidRequestException extends GenericException {

    String message;

    public InvalidRequestException(MusicApiError musicApiError, String message) {
        super(musicApiError);
        this.message = message;

    }
}
