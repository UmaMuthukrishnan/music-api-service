package com.music.musicproviderapi.request;

import lombok.Getter;
import lombok.Setter;

/**
 * Request class of ArtistRequest
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
@Setter
public class ArtistRequest {
    private String artistName;

}
