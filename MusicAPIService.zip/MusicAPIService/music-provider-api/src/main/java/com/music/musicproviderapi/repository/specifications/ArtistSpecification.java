package com.music.musicproviderapi.repository.specifications;

import com.music.musicproviderapi.entity.Artist;
import com.music.musicproviderapi.entity.Artist_;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;
/**
 * Specification for filtering  Artist
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
public class ArtistSpecification {
    public static Specification<Artist> artistNameContainsIgnoreCase(String searchTerm) {
        return (root, query, cb) -> cb.like(cb.lower(root.get(Artist_.artistName)), searchTerm);
    }
}
