package com.music.musicproviderapi.controller;

import com.music.musicproviderapi.exceptions.InvalidRequestException;
import com.music.musicproviderapi.model.ArtistModel;
import com.music.musicproviderapi.model.MusicApiError;
import com.music.musicproviderapi.model.SortType;
import com.music.musicproviderapi.request.ArtistRequest;
import com.music.musicproviderapi.service.ArtistService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


/**
 * Rest Controller class for Artist endpoints
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@RestController
@Slf4j
@RequestMapping("/artists")
public class ArtistController {

    private static final String INVALID_ARTIST_REQUEST_ERROR_CODE = "MSAPI-ARTIST-001";
    private static final String INVALID_ARTIST_REQUEST_ERROR_DESC = "INVALID ALBUM REQUEST";
    private final ArtistService artistService;

    @Autowired
    public ArtistController(ArtistService artistService) {
        this.artistService = artistService;

    }

    /**
     * Create/Add an new  artist in music database
     *
     * @param artistRequest Request with { artistName}
     *                      in json format
     * @return persisted/created ResponseEntity<ArtistModel> object encloses {Artist}
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaTypes.HAL_JSON_VALUE)
    @ApiOperation(value = "Create New Artist")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Successfully created "),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "Resource Not Found")
    })
    public ResponseEntity<ArtistModel> createNewArtist(@RequestBody ArtistRequest artistRequest) {

        log.info("-----Creating New Artist --------");
        if (artistRequest == null || (artistRequest.getArtistName() == null)) {
            throw new InvalidRequestException
                    (new MusicApiError(INVALID_ARTIST_REQUEST_ERROR_CODE, INVALID_ARTIST_REQUEST_ERROR_DESC,
                            HttpStatus.BAD_REQUEST), "Enter a valid request");
        }
        final ArtistModel artistModel = artistService.createNewArtist(artistRequest);
        return new ResponseEntity<>(artistModel, HttpStatus.CREATED);
    }

    /**
     * Retrieves the details of the persisted/created Artist in the music database
     *
     * @param artistId artistID from the persisted entry in database
     * @return ResponseEntity<ArtistModel> object encloses {Artist}
     */
    @GetMapping(value = "/{artistId}", produces = MediaTypes.HAL_JSON_VALUE)
    @ApiOperation(value = "Get an existing Artist")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Retrieved "),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "Resource Not Found")
    })
    public ResponseEntity<ArtistModel> getArtistByArtistId(@PathVariable("artistId") Long artistId) {
        log.info("-----Get an existing Artist by Id --------");
        if (artistId <= 0) {
            throw new InvalidRequestException
                    (new MusicApiError(INVALID_ARTIST_REQUEST_ERROR_CODE, INVALID_ARTIST_REQUEST_ERROR_DESC,
                            HttpStatus.BAD_REQUEST), "Enter a valid request");
        }
        final ArtistModel newArtist = artistService.getAnArtist(artistId);
        return new ResponseEntity<>(newArtist, HttpStatus.OK);

    }

    /**
     * Updates the existing artist in the music database
     *
     * @param artistId      artistID from the persisted entry in database
     * @param artistRequest Request with { artistName}
     *                      in json format
     * @return persisted/updated ResponseEntity<ArtistModel> object encloses {Artist}
     */
    @PutMapping(value = "/{artistId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaTypes.HAL_JSON_VALUE)
    @ApiOperation(value = "Update existing Artist")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Updated "),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "Resource Not Found")
    })
    public ResponseEntity<ArtistModel> updateArtist(@PathVariable("artistId") Long artistId, @RequestBody ArtistRequest artistRequest) {
        log.info("-----Updating an existing Artist --------");
        if (artistId <= 0 || artistRequest == null) {
            throw new InvalidRequestException
                    (new MusicApiError(INVALID_ARTIST_REQUEST_ERROR_CODE, INVALID_ARTIST_REQUEST_ERROR_DESC,
                            HttpStatus.BAD_REQUEST), "Enter a valid request");
        }
        final ArtistModel updatedArtist = artistService.updateArtist(artistId, artistRequest);
        return new ResponseEntity<>(updatedArtist, HttpStatus.OK);
    }

    /**
     * Method to retrieve all existing artists based on below parameters
     *
     * @param searchByName artistName
     * @param sortType     artistName (either ASC/DESC)
     * @param pageable     Pageable param for pagination
     * @return responseEntity of paginated ArtistModel
     */

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @ApiOperation(value = "Retrieves all existing artists")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved all existing artists"),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "Resource Not Found")
    })
    public ResponseEntity<Page<ArtistModel>> getAllArtists(@RequestParam(value = "ArtistName", defaultValue = "", required = false) String searchByName,
                                                           @RequestParam(value = "SortBy", defaultValue = "", required = false) SortType sortType, Pageable pageable) {

        log.info("-----Executing getAllArtists--------");
        final Page<ArtistModel> pageableArtistModel = artistService.findAllArtist(searchByName, sortType, pageable);
        return new ResponseEntity<>(pageableArtistModel, HttpStatus.OK);
    }


}
