package com.music.musicproviderapi.exceptions;

import com.music.musicproviderapi.model.MusicApiError;
import lombok.Getter;


/** DbException Handler for the API
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
public class DatabaseException extends GenericException {

    private MusicApiError musicApiError;

    public DatabaseException(MusicApiError error, String message) {
        super(message);
        this.musicApiError = error;
    }

    public DatabaseException(String message, Exception cause) {
        super(message, cause);
    }
}
