package com.music.musicproviderapi.exceptions;

import com.music.musicproviderapi.model.MusicApiError;
import lombok.Getter;


/**
 * JsonOperationException Exception class
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
public class JsonOperationException extends GenericException {

    String message;

    public JsonOperationException(MusicApiError error, String message) {
        super(error);
        this.message = message;

    }
}
