package com.music.musicproviderapi.repository.specifications;

import com.music.musicproviderapi.entity.Album;
import com.music.musicproviderapi.entity.Album_;
import com.music.musicproviderapi.entity.Genre;
import com.music.musicproviderapi.entity.Genre_;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import javax.persistence.criteria.ListJoin;
import javax.persistence.criteria.Path;
import java.util.List;

/**
 * Specification for filtering  Albums
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
public class ArtistAlbumSpecification {
    public static Specification<Album> findByArtistId(Long artistId) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.equal(root.get(Album_.ARTIST), artistId);
    }

    static Specification<Album> findByGenreList(final List<String> genres) {
        return (Specification<Album>) (root, query, cb) -> {
            ListJoin<Album, Genre> albumGenreListJoin = root.join(Album_.genres);
            Path<String> albumGenres = albumGenreListJoin.get(Genre_.genreName);
            return albumGenres.in(genres);

        };
    }

    public static Specification<Album> getAlbumsByArtistIdAndGenres(Long artistId,
                                                             List<String> genres) {
        return Specification.where(findByArtistId(artistId))
                .and(findByGenreList(genres));
    }
}
