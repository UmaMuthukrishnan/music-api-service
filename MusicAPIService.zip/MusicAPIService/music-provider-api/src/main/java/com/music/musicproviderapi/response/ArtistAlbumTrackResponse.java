package com.music.musicproviderapi.response;

import lombok.*;

/**
 * ArtistAlbumTrackResponse Response class
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ArtistAlbumTrackResponse {

    private String artistName;
    private String albumName;
    private AlbumTrackList albumTrackList;
}
