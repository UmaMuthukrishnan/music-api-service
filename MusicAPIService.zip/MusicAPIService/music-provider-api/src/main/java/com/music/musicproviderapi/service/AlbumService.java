package com.music.musicproviderapi.service;

import com.music.musicproviderapi.controller.AlbumController;
import com.music.musicproviderapi.entity.*;
import com.music.musicproviderapi.exceptions.AlbumNotFoundException;
import com.music.musicproviderapi.exceptions.ArtistNotFoundException;
import com.music.musicproviderapi.model.AlbumModel;
import com.music.musicproviderapi.model.SortType;
import com.music.musicproviderapi.repository.AlbumRepository;
import com.music.musicproviderapi.repository.ArtistRepository;
import com.music.musicproviderapi.repository.specifications.ArtistAlbumSpecification;
import com.music.musicproviderapi.request.AlbumRequest;
import com.music.musicproviderapi.response.AlbumTrackList;
import com.music.musicproviderapi.response.ArtistAlbumTrackResponse;
import com.music.musicproviderapi.serviceClient.DiscogsAPIServiceClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

/**
 * Service class for getting artist-album details
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Service
public class AlbumService {

    private final AlbumRepository albumRepository;

    private final ArtistRepository artistRepository;

    private final DiscogsAPIServiceClient discogsAPIServiceClient;
    private static final String ALBUM_NAME_PARAM = "albumName";
    private static final String RELEASE_YEAR_PARAM = "releaseYear";


    @Autowired
    public AlbumService(AlbumRepository albumRepository, ArtistRepository artistRepository, DiscogsAPIServiceClient discogsAPIServiceClient) {
        this.albumRepository = albumRepository;
        this.artistRepository = artistRepository;
        this.discogsAPIServiceClient = discogsAPIServiceClient;
    }

    /**
     * Method to create/Add an new album for an artist in music database
     *
     * @param artistId     given artistID from the music database
     * @param albumRequest Request with { String albumName,String releaseYear,List<String> genres}
     *                     in json format
     * @return AlbumModel with created Album object
     */
    public AlbumModel createNewAlbumForAnArtist(Long artistId, AlbumRequest albumRequest) {
        Album newAlbum = null;
        if (albumRequest != null) {
            if (artistId > 0) {
                Optional<Artist> optionalArtist = artistRepository.findById(artistId);
                if (optionalArtist.isPresent()) {
                    Artist existingArtist = optionalArtist.get();
                    List<Genre> genreList = new ArrayList<>(albumRequest.getGenres());
                    newAlbum = albumRepository.saveAndFlush(Album.builder()
                            .albumName(albumRequest.getAlbumName())
                            .artist(existingArtist)
                            .genres(genreList)
                            .releaseYear(Integer.parseInt(albumRequest.getReleaseYear()))
                            .build());
                } else {
                    throw new ArtistNotFoundException("ArtistId " + artistId + " not found");
                }
            }
        }
        Link selfLink = linkTo(methodOn(AlbumController.class)
                .addNewAlbumForArtist(artistId, albumRequest))
                .withSelfRel();
        return AlbumModel.builder().album(newAlbum).build().add(selfLink);
    }

    /**
     * Method to update an existing album for an artist in the music database
     *
     * @param artistId     artistID from the persisted entry in database
     * @param albumId      albumID from the persisted entry in database
     * @param albumRequest Request with { String albumName,String releaseYear,List<String> genres}
     *                     in json format
     * @return persisted/updated ResponseEntity<AlbumModel> object encloses {Album}
     */

    public AlbumModel updateAlbumForArtist(Long artistId, Long albumId, AlbumRequest albumRequest) {
        Album updatedAlbum = null;
        if (!artistRepository.existsById(artistId)) {
            throw new ArtistNotFoundException("ArtistId " + artistId + " not found");
        }
        if (albumRequest != null && albumId > 0) {
            updatedAlbum = albumRepository.findById(albumId).map(album -> {
                mapAlbumDetails(albumRequest, album);
                return albumRepository.saveAndFlush(album);
            }).orElseThrow(() -> new AlbumNotFoundException("AlbumId " + albumId + "not found"));
        }
        Link selfLink = linkTo(methodOn(AlbumController.class)
                .updateAlbumForArtist(artistId, albumId, albumRequest))
                .withSelfRel();
        return AlbumModel.builder().album(updatedAlbum).build().add(selfLink);
    }

    /**
     * Method to map the album details from AlbumRequest
     *
     * @param albumRequest albumRequest
     * @param album        Album object to be mapped
     */
    private void mapAlbumDetails(AlbumRequest albumRequest, Album album) {
        if (albumRequest.getAlbumName() != null) {
            album.setAlbumName(albumRequest.getAlbumName());
        }
        if (albumRequest.getGenres() != null) {
            List<Genre> genreList = new ArrayList<>(albumRequest.getGenres());
            album.getGenres().addAll(genreList);
        }
        if (albumRequest.getReleaseYear() != null) {
            album.setReleaseYear(Integer.parseInt(albumRequest.getReleaseYear()));
        }
    }

    /**
     * Retrieves all the albums of an artist with pagination
     *
     * @param artistId      artistID from the persisted entry in database
     * @param albumSortType ASC/DESC based on album name
     * @param yearSortType  ASC/DESC based on year
     * @param genreList     Genres as a list
     * @param pageable      Paginated object
     * @return Paginated AlbumModel object {Album}
     */
    public Page<AlbumModel> getAllAlbumsByArtist(Long artistId, SortType albumSortType, SortType yearSortType, List<String> genreList, Pageable pageable) {
        Page<Album> pagedResult = null;
        if (!artistRepository.existsById(artistId)) {
            throw new ArtistNotFoundException("ArtistId " + artistId + " not found");
        }
        if (albumSortType != null) {
            pageable = getSortedPageable(albumSortType, ALBUM_NAME_PARAM, pageable);
        }
        if (yearSortType != null) {
            pageable = getSortedPageable(yearSortType, RELEASE_YEAR_PARAM, pageable);
        }

        if (artistId > 0) {
            Specification<Album> albumSpecification;
            if (genreList != null && genreList.size() > 0) {
                albumSpecification= ArtistAlbumSpecification.getAlbumsByArtistIdAndGenres(artistId, genreList);
            } else {
                albumSpecification = ArtistAlbumSpecification.findByArtistId(artistId);
            }
            pagedResult = albumRepository.findAll(albumSpecification, pageable);
        }
        List<AlbumModel> albumModelList = new ArrayList<>();
        if (pagedResult != null && pagedResult.getContent().size() > 0) {
            pagedResult.getContent().stream().forEachOrdered(album -> {
                albumModelList.add(AlbumModel.builder().album(album).build());
            });
        }
        return new PageImpl<>(albumModelList);
    }

    /**
     * @param sortType     SortType enum (ASC/DESC)
     * @param sortByString string either albumName/releaseYear
     * @param pageable     Pageable object
     * @return sorted Pageable object
     */
    private Pageable getSortedPageable(SortType sortType, String sortByString, Pageable pageable) {
        if (sortType == SortType.ASC) {
            pageable = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(sortByString).ascending());
        } else if (sortType == SortType.DESC) {
            pageable = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(sortByString).descending());
        }
        return pageable;
    }

    /**
     * Method to get more details about an album of an artist
     * from the serviceClient discogsAPIServiceClient
     *
     * @param artistId artistID from the persisted entry in database
     * @param albumId  albumID from the persisted entry in database
     * @return ResponseEntity<AlbumModel> object encloses {ArtistAlbumTrackResponse}
     */
    public ArtistAlbumTrackResponse getAlbumDetailsOfAnArtist(Long artistId, Long albumId) {
        ArtistAlbumTrackResponse artistAlbumTrackResponse = null;
        Optional<Artist> optionalArtist = artistRepository.findById(artistId);
        Optional<Album> optionalAlbum = albumRepository.findById(albumId);
        String artistName;
        String albumName;
        if (optionalArtist.isPresent()) {
            Artist artist = optionalArtist.get();
            artistName = artist.getArtistName();
        } else {
            throw new ArtistNotFoundException("Artist for " + artistId + " not found");
        }

        if (optionalAlbum.isPresent()) {
            Album album = optionalAlbum.get();
            albumName = album.getAlbumName();
        } else {
            throw new AlbumNotFoundException("Album for " + artistId + " not found");
        }

        if (artistName != null && albumName != null) {
            AlbumTrackList albumTrackList = discogsAPIServiceClient.getArtistAlbumTracks(albumName, artistName);
            artistAlbumTrackResponse = ArtistAlbumTrackResponse.builder().albumName(albumName)
                    .artistName(artistName)
                    .albumTrackList(albumTrackList).build();
        }
        return artistAlbumTrackResponse;
    }

}
