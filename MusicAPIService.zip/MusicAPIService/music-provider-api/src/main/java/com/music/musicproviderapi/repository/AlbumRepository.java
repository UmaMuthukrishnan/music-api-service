package com.music.musicproviderapi.repository;

import com.music.musicproviderapi.entity.Album;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;


/**
 * Repository class for Album
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Repository
public interface AlbumRepository extends JpaRepository<Album, Long>, JpaSpecificationExecutor<Album> {

    Page<Album> findAll(Specification<Album> genres, Pageable pageable);

}
