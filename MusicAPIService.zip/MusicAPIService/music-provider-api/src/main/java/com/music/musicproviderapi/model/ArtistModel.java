package com.music.musicproviderapi.model;

import com.music.musicproviderapi.entity.Artist;
import lombok.*;
import org.springframework.hateoas.RepresentationModel;

/**
 * Model class for Artist
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class ArtistModel extends RepresentationModel<ArtistModel> {
    private Artist artist;
}
