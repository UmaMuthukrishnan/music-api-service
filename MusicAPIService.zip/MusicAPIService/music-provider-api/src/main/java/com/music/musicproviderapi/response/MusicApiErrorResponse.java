package com.music.musicproviderapi.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.music.musicproviderapi.model.MusicApiError;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Model class to handle all the API response errors
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
@Setter
public class MusicApiErrorResponse {
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<MusicApiError> musicApiErrorList = new ArrayList<>();
}
