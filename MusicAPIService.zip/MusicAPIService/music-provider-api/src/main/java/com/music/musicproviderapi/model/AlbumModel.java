package com.music.musicproviderapi.model;

import com.music.musicproviderapi.entity.Album;
import lombok.*;
import org.springframework.hateoas.RepresentationModel;

/**
 * Model class for Album
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class AlbumModel extends RepresentationModel<AlbumModel> {

    private Album album;
}
