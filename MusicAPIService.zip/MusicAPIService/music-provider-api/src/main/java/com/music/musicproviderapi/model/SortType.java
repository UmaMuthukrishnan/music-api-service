package com.music.musicproviderapi.model;


import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Enum representing the possible
 * values for a SORT parameter
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@AllArgsConstructor
@Getter
public enum SortType {

    ASC("ASC"),
    DESC("DESC");

    private final String orderBy;

}
