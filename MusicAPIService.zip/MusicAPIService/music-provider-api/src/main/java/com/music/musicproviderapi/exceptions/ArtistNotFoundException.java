package com.music.musicproviderapi.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception class for ArtistNotFoundException
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class ArtistNotFoundException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ArtistNotFoundException(String exception) {
        super(exception);
    }
}
