package com.music.musicproviderapi.serviceClient;

import com.music.musicproviderapi.response.AlbumTrackList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * DiscogsAPIServiceClient class to consume
 * <p>
 * DiscogsAPI provider(Registered in Eureka Naming server as "DISCOGS-INFORMATION-SERVICE")
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Service
@Slf4j
public class DiscogsAPIServiceClient {

    @Value("${discogs-api-url-path}")
    private String discogsPathUrl;

    @Value("${discogs-api-provider-name}")
    private String discogsApiProvider;

    @Value("${discogs-api-releaseTitle-param}")
    private String releaseTitleParam;

    @Value("${discogs-api-artist-param}")
    private String artistNameParam;


    private final DiscoveryClient discoveryClient;

    @Autowired
    public DiscogsAPIServiceClient(DiscoveryClient discoveryClient) {
        this.discoveryClient = discoveryClient;

    }

    /**
     * Method to get Master releases(Albums) track details of an Artist
     * <p>
     * Do a Webclient call with the provider service
     * to get the details of AlbumTrackDetails based on below params
     *
     * @param releaseTitle albumName/release_title
     * @param artist       artistName
     * @return AlbumTrackList with {AlbumTrackResponse}
     * <p>
     * Note::This method is to search only the master release_tiles/albums of an artist
     */
    public AlbumTrackList getArtistAlbumTracks(String releaseTitle, String artist) {
        List<ServiceInstance> instances = discoveryClient.getInstances(discogsApiProvider);
        ServiceInstance serviceInstance = instances.get(0);
        String baseUrl = serviceInstance.getUri().toString();
        return WebClient.builder().baseUrl(baseUrl).build()
                .get()
                .uri(uriBuilder -> uriBuilder
                        .path(discogsPathUrl)
                        .queryParam(releaseTitleParam, releaseTitle)
                        .queryParam(artistNameParam, artist)
                        .build())
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .accept(MediaType.APPLICATION_JSON)
                .acceptCharset(StandardCharsets.UTF_8)
                .retrieve()
                .bodyToMono(AlbumTrackList.class)
                .block();
    }
}
