package com.music.musicproviderapi.request;

import com.music.musicproviderapi.entity.Genre;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Request class of AlbumRequest
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */


@Getter
@Setter
public class AlbumRequest {

    private String albumName;
    private String releaseYear;
    private List<Genre> genres;

}
