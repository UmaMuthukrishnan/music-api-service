package com.music.musicproviderapi.entity;

import lombok.*;

import javax.persistence.*;

/**
 * Entity class for Artist
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Entity
@Table(name = "artist")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Artist {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "artist_id")
    private Long artistId;
    private String artistName;
}
