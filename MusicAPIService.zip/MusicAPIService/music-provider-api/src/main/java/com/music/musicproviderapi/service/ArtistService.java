package com.music.musicproviderapi.service;

import com.music.musicproviderapi.controller.ArtistController;
import com.music.musicproviderapi.entity.Artist;
import com.music.musicproviderapi.exceptions.ArtistNotFoundException;
import com.music.musicproviderapi.model.ArtistModel;
import com.music.musicproviderapi.model.SortType;
import com.music.musicproviderapi.repository.ArtistRepository;
import com.music.musicproviderapi.repository.specifications.ArtistSpecification;
import com.music.musicproviderapi.request.ArtistRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

/**
 * Service class for getting artist details
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Service
public class ArtistService {

    private final ArtistRepository artistRepository;

    @Autowired
    public ArtistService(ArtistRepository artistRepository) {
        this.artistRepository = artistRepository;
    }

    /**
     * Retrieves the details of the persisted/created Artist in the music database
     *
     * @param artistId artistID from the persisted entry in database
     * @return ResponseEntity<ArtistModel> object encloses {Artist}
     */
    public ArtistModel getAnArtist(Long artistId) {
        Artist newArtist = artistRepository.findById(artistId).orElseThrow(() -> new ArtistNotFoundException("ArtistId " + artistId + " not found"));
        Link selfLink = linkTo(methodOn(ArtistController.class).getArtistByArtistId(artistId))
                .withSelfRel();
        return ArtistModel.builder().artist(newArtist).build().add(selfLink);
    }

    public Page<ArtistModel> findAllArtist(String artistName, SortType sortType, Pageable pageable) {
        if (sortType != null) {
            if (sortType == SortType.ASC) {
                pageable = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by("artistName").ascending());
            } else if (sortType == SortType.DESC) {
                pageable = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by("artistName").descending());
            }
        }
        Page<Artist> pagedResult;
        if (artistName != null && !artistName.isEmpty()) {
            String formattedString = getContainsLikePattern(artistName);
            pagedResult = artistRepository.findAll(ArtistSpecification.artistNameContainsIgnoreCase(formattedString), pageable);
        } else {
            pagedResult = artistRepository.findAll(pageable);
        }
        List<ArtistModel> artistModelList = new ArrayList<>();
        if (pagedResult != null && pagedResult.getContent().size() > 0) {
            pagedResult.getContent().stream()
                    .forEachOrdered(artist -> {
                        Link selfLink = linkTo(methodOn(ArtistController.class).getArtistByArtistId(artist.getArtistId()))
                                .withRel("Get An Artist");
                        artistModelList.add(ArtistModel.builder().artist(artist).build().add(selfLink));
                    });
        }
        return new PageImpl<>(artistModelList);
    }

    /**
     * Method to format the string for like pattern
     * @param searchTerm searchString
     * @return formatted string
     */
    private static String getContainsLikePattern(String searchTerm) {
        if (searchTerm == null || searchTerm.isEmpty()) {
            return "%";
        } else {
            return "%" + searchTerm.toLowerCase() + "%";
        }
    }
    /**
     * Create/Add an new  artist in music database
     *
     * @param artistRequest Request with { artistName}
     *                      in json format
     * @return persisted/created ResponseEntity<ArtistModel> object encloses {Artist}
     */
    public ArtistModel createNewArtist(ArtistRequest artistRequest) {
        Artist newArtist = null;

        if (artistRequest != null) {
            newArtist = artistRepository.saveAndFlush(Artist.builder()
                    .artistName(artistRequest.getArtistName()).build());
        }
        Link selfLink = linkTo(methodOn(ArtistController.class).createNewArtist(artistRequest))
                .slash(newArtist != null ? newArtist.getArtistId() : 0)
                .withSelfRel();

        return ArtistModel.builder().artist(newArtist).build().add(selfLink);
    }

    /**
     * Updates the existing artist in the music database
     *
     * @param artistId      artistID from the persisted entry in database
     * @param artistRequest Request with { artistName}
     *                      in json format
     * @return persisted/updated ResponseEntity<ArtistModel> object encloses {Artist}
     */
    public ArtistModel updateArtist(Long artistId, ArtistRequest artistRequest) {
        Artist updatedArtist = null;
        if (artistId > 0 && artistRequest != null) {
            Optional<Artist> optionalArtist = artistRepository.findById(artistId);
            if (optionalArtist.isPresent()) {
                Artist existingArtist = optionalArtist.get();
                existingArtist.setArtistName(artistRequest.getArtistName());
                updatedArtist = artistRepository.saveAndFlush(existingArtist);
            } else {
                throw new ArtistNotFoundException("ArtistId " + artistId + " not found");
            }
        }
        Link selfLink = linkTo(methodOn(ArtistController.class).updateArtist(artistId, artistRequest))
                .withSelfRel();
        return ArtistModel.builder().artist(updatedArtist).build().add(selfLink);

    }

}
