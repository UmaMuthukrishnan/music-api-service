package com.music.musicproviderapi.response;

import com.music.musicproviderapi.entity.Artist;
import lombok.*;

/**
 * ArtistResponse Response class
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ArtistResponse {

    private Artist artist;

}
