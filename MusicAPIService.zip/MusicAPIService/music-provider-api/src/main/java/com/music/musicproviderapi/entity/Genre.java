package com.music.musicproviderapi.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;

@Entity
@Table(name = "genre")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class Genre {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="genre_id")
    @JsonIgnore
    private Long genreId;
    private String genreName;
//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "album_id", nullable = false)
   // private Album album;
}
