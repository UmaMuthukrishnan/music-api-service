package com.music.musicproviderapi.controller;

import com.music.musicproviderapi.exceptions.InvalidRequestException;
import com.music.musicproviderapi.model.AlbumModel;
import com.music.musicproviderapi.model.MusicApiError;
import com.music.musicproviderapi.model.SortType;
import com.music.musicproviderapi.request.AlbumRequest;
import com.music.musicproviderapi.response.ArtistAlbumTrackResponse;
import com.music.musicproviderapi.service.AlbumService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * Rest Controller class for Artist Album endpoints
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@RestController
@Slf4j
@RequestMapping("/artists/{artistId}/albums")
public class AlbumController {

    private static final String INVALID_ALBUM_REQUEST_ERROR_CODE = "MSAPI-ALBUM-001";
    private static final String INVALID_ALBUM_REQUEST_ERROR_DESC = "INVALID ALBUM REQUEST";
    private final AlbumService albumService;

    @Autowired
    public AlbumController(AlbumService albumService) {
        this.albumService = albumService;
    }

    /**
     * Retrieves all the albums of an artist with pagination
     *
     * @param artistId      artistID from the persisted entry in database
     * @param albumSortType ASC/DESC based on album name
     * @param yearSortType  ASC/DESC based on year
     * @param genres        Genres as a list
     * @param pageable      Paginated object
     * @return Paginated AlbumModel object {Album}
     */
    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @ApiOperation(value = "Retrieves all the albums of an artist")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "Resource Not Found")
    })
    public ResponseEntity<Page<AlbumModel>> getAllAlbumsForArtist(
            @PathVariable("artistId") Long artistId,
            @RequestParam(value = "albumSort", required = false) SortType albumSortType,
            @RequestParam(value = "yearSortType", required = false) SortType yearSortType,
            @RequestParam(value = "genres", required = false) List<String> genres,
            Pageable pageable) {
        log.info("---Getting Album details an Artist -----");
        if (artistId <= 0) {
            throw new InvalidRequestException
                    (new MusicApiError(INVALID_ALBUM_REQUEST_ERROR_CODE, INVALID_ALBUM_REQUEST_ERROR_DESC,
                            HttpStatus.BAD_REQUEST), "Enter a valid request");
        }
        Page<AlbumModel> pageableAlbumModel = albumService.getAllAlbumsByArtist(artistId, albumSortType, yearSortType, genres, pageable);
        return new ResponseEntity<>(pageableAlbumModel, HttpStatus.OK);
    }

    /**
     * Create/Add an new album for an artist in music database
     *
     * @param artistId     artistID from the persisted entry in database
     * @param albumRequest Request with { String albumName,String releaseYear,List<String> genres}
     *                     in json format
     * @return persisted/created ResponseEntity<AlbumModel> object encloses {Album}
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaTypes.HAL_JSON_VALUE)
    @ApiOperation(value = " Add a new album to an existing artist", response = AlbumModel.class)
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Successfully created"),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "Resource Not Found")
    })
    public ResponseEntity<AlbumModel> addNewAlbumForArtist(
            @PathVariable("artistId") Long artistId,
            @RequestBody AlbumRequest albumRequest) {

        log.info("---Creating An Album for an Artist -----");
        if (artistId <= 0 || albumRequest == null) {
            throw new InvalidRequestException
                    (new MusicApiError(INVALID_ALBUM_REQUEST_ERROR_CODE, INVALID_ALBUM_REQUEST_ERROR_DESC,
                            HttpStatus.BAD_REQUEST), "Enter a valid request");
        }
        final AlbumModel albumModel = albumService.createNewAlbumForAnArtist(artistId, albumRequest);
        return new ResponseEntity<>(albumModel, HttpStatus.CREATED);
    }

    /**
     * Updates an existing album for an artist in the music database
     *
     * @param artistId     artistID from the persisted entry in database
     * @param albumId      albumID from the persisted entry in database
     * @param albumRequest Request with { String albumName,String releaseYear,List<String> genres}
     *                     in json format
     * @return persisted/updated ResponseEntity<AlbumModel> object encloses {Album}
     */
    @PutMapping(value = "/{albumId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaTypes.HAL_JSON_VALUE)
    @ApiOperation(value = "Update an existing Album of an artist", response = AlbumModel.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully updated "),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "Resource Not Found")
    })
    public ResponseEntity<AlbumModel> updateAlbumForArtist(
            @PathVariable("artistId") Long artistId, @PathVariable("albumId") Long albumId,
            @RequestBody AlbumRequest albumRequest) {
        log.info("---Updating an Album for an Artist -----");
        if (artistId <= 0 || albumId <= 0 || albumRequest == null) {
            throw new InvalidRequestException
                    (new MusicApiError(INVALID_ALBUM_REQUEST_ERROR_CODE, INVALID_ALBUM_REQUEST_ERROR_DESC,
                            HttpStatus.BAD_REQUEST), "Enter a valid request");
        }
        final AlbumModel albumModel = albumService.updateAlbumForArtist(artistId, albumId, albumRequest);
        return new ResponseEntity<>(albumModel, HttpStatus.OK);
    }

    /**
     * Method to get more details about an album of an artist
     * by connecting to a third party service : DiscogsApi Service(Registered in Eureka)
     *
     * @param artistId artistID from the persisted entry in database
     * @param albumId  albumID from the persisted entry in database
     * @return ResponseEntity<AlbumModel> object encloses {ArtistAlbumTrackResponse}
     */
    @GetMapping(value = "/{albumId}", produces = MediaTypes.HAL_JSON_VALUE)
    @ApiOperation(value = "Get more details about an album of an artist", response = ArtistAlbumTrackResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved album details for Artist"),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "Resource Not Found")
    })
    public ResponseEntity<ArtistAlbumTrackResponse> getAlbumDetailsOfAnArtist(@PathVariable("artistId") Long artistId, @PathVariable("albumId") Long albumId) {
        log.info("---Getting more details about an Album of an Artist -----");
        if (artistId <= 0 || albumId <= 0) {
            throw new InvalidRequestException
                    (new MusicApiError(INVALID_ALBUM_REQUEST_ERROR_CODE, INVALID_ALBUM_REQUEST_ERROR_DESC,
                            HttpStatus.BAD_REQUEST), "Enter a valid request");
        }
        ArtistAlbumTrackResponse artistAlbumTrackResponse = albumService.getAlbumDetailsOfAnArtist(artistId, albumId);
        return new ResponseEntity<>(artistAlbumTrackResponse, HttpStatus.OK);
    }
}
