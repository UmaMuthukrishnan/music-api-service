package com.music.musicproviderapi.response;

import com.music.musicproviderapi.model.Track;
import lombok.*;

import java.util.List;

/**
 * AlbumTrackResponse Response class
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AlbumTrackResponse {

    private String title;
    private List<Track> trackList;
    private String resourceUrl;
}
