package com.music.musicproviderapi.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.util.List;

/**
 * Entity class for Album
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Entity
@Table(name = "album")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Album {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "album_id")
    private Long albumId;
    private String albumName;
    private Integer releaseYear;
        @OneToMany(cascade = CascadeType.ALL,orphanRemoval = true)
        @JoinColumn(name = "album_id")
    private List <Genre> genres;
//    @ElementCollection(fetch = FetchType.LAZY)
//    @CollectionTable(
//            name = "genre",
//            joinColumns = @JoinColumn(name = "album_Id")
//    )
//    @Column(name = "genres")
//    private List<String> genres;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "artist_id", nullable = false)
    @JsonIgnore
    private Artist artist;

}
