package com.music.musicproviderapi.exceptions;

import com.music.musicproviderapi.model.MusicApiError;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * GenericException Handler for the API
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
@NoArgsConstructor
public class GenericException extends RuntimeException {

    private MusicApiError musicApiError;

    public GenericException(String description) {
        super(description);
    }

    public GenericException(String description, Exception cause) {
        super(description, cause);
    }

    public GenericException(MusicApiError musicApiError) {
        this.musicApiError = musicApiError;

    }

}
