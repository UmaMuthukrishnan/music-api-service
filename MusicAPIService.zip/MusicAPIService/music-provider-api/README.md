## Technical stack requirements
Maven,
JDK 8,
Spring Boot 2.2.6
Database:In-Memory (H2)
Query Executor: JPA Specifications

Approach: I have implemented microservices architecture here.

##About : MusicAPI service
 Microservices Architecture is used in designing MusicAPI service.
 
 There are two services namely music-provider-api and discogs-info-api are involved here.
 
 The music-provider-api (aka) consumer ,which consumes the discogs-info-api for providing
 more details about the artist's album details.
 
 The discogs-info-api service (aka) producer ,provides data to the music-provider-service.
 
 This interacts with another third party service namely Discogs-API,to get details about the artist's album data.
 It uses basic user authentication for consuming the Discogs-API.
 
 (OAuth is a good option to securely accessing the above API ,but I haven't implemented it due to time constraints.)
 
 Both the music-provider-api and discogs-info-api services are registered in Eureka naming server.Eureka,acts as a discovery
 server,so that the services can be used in other services with the name tagged to Eureka,rather than defining a name and port.
  
## Steps to be followed for accessing endpoints.

1. Start Eureka Discovery Server
2. Start discogs-info-api service
3. Start music-provider-api service


All the above mentioned services are dockerized. Use docker-compose.yml file for running the application in docker.

#####Note: Enable annotation-processing option in IDE while running maven build, as JPA specifications are used in creating the testcases.

##Accessing RestAPI endpoints

1. Created a separate controller for artist (/artists endpoint to manage Artist data)
      i)  POST /artists to save a new artist 
                -Accepts ArtistName wrapped in ArtistRequest(In future if we want to add either firstName/lastName)
      
      ii) PUT /artists/{artistId} to update an existing artist
                -Accepts ArtistID and ArtistName wrapped in ArtistRequest
      
      iii) GET /artists/{artistId} to get details of an existing artist
                      -Accepts ArtistID          
                
      iv) GET /artists lists all artists.(Accepts either one /all of the below filters)
                -Implemented  filtering by a part of artist name
                -sorting by artist name (asc/desc)
                -Pagination              

2. Created a separate controller for album (/artists/{artistId}/albums) to manage Album data 
      
      i)  POST /artists/{artistId}/albums to add a new album to an existing artist
                 -Accepts artistId && Album details wrapped AlbumRequest(title,year of release, genres (list of tags))
      
      ii) PUT /artists/{artistId}/albums/{albumId} to update an existing album
                -Accepts artistId && Album details wrapped AlbumRequest(title,year of release, genres (list of tags))
                
      iii) GET /artists/{artistId}/albums lists all albums by the given artist. 
                -Implemented filtering by genre(s) && sorting by album name and release year (asc/desc)

      iv) GET /artists/{artistId}/albums/{albumId} to retrieve more details about an individual album using a 3rd party service
                -Accepts valid artistID && albumId in Long
                -Created a DiscogsAPIServiceClient to interact with the third party service DiscogsAPI
                -Implemented a search to get only the master releases
                -Method will return track listing using the resource_url(s) of the found album.

Note: Used WebClient to interact with the API calls instead of RestTemplate.

## Extra requirements
1. Included Actuator to expose both  
     - Metrics && Health checks
2. Took baby steps in implementing Reactive approach using Webclient 
3. Dockerized and implemented swagger to view the endpoints via,
        http://localhost:8080/swagger-ui.html