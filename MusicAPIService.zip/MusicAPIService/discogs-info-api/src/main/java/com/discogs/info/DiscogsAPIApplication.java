
package com.discogs.info;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

/**
 * Provider for DiscogsAPI Service
 * <p>
 * Main Class for DiscogsAPI Application
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@SpringBootApplication
@EnableEurekaClient
public class DiscogsAPIApplication {
    public static void main(String[] args) {
        SpringApplication.run(DiscogsAPIApplication.class, args);
    }
}
