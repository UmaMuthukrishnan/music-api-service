package com.discogs.info.model;

import lombok.*;

/**
 * Track Model class
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class Track {
    String trackNumber;
    String trackTitle;

}
