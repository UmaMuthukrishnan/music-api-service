package com.discogs.info.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.springframework.http.HttpStatus;

import java.util.Date;

/**
 * DiscogsInfoError class
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DiscogsInfoError {

    public DiscogsInfoError(String errorCode, String description, HttpStatus httpStatus) {
        this.errorCode = errorCode;
        this.description = description;
        this.httpStatus = httpStatus;
    }

    private String errorCode;
    private String description;
    private Date timestamp;
    @JsonIgnore
    private HttpStatus httpStatus;
    private String requestURI;


}

