package com.discogs.info.exception;

import com.discogs.info.model.DiscogsInfoError;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * GenericException Handler for the API
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class GenericException extends RuntimeException {

    private DiscogsInfoError discogsInfoError;

}
