package com.discogs.info.response;

import com.discogs.info.model.DiscogsInfoError;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Model class to handle all the API response errors
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
@Setter
public class DiscogsInfoErrorResponse {
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<DiscogsInfoError> discogsInfoErrorList = new ArrayList<>();
}
