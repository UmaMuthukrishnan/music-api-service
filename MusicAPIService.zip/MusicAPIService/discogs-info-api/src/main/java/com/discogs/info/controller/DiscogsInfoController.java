package com.discogs.info.controller;

import com.discogs.info.response.AlbumTrackList;
import com.discogs.info.service.DiscogsInformationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Rest Controller class for accessing a third party service : DiscogsAPIApplication
 *
 * @author Uma Muthukrishnan
 * @version 1.0
 *
 */
@RestController
@Slf4j
@RequestMapping("/discogsInfo")
public class DiscogsInfoController {

    private final DiscogsInformationService informationService;

    @Autowired
    public DiscogsInfoController(DiscogsInformationService informationService) {
        this.informationService = informationService;
    }

    /**
     * An api to get tracks of Albums from a third party service : DiscogsAPIApplication based on below parameters
     *
     * @param releaseTitle albumName
     * @param artistName   artist name
     * @return AlbumTrackList which holds information about title,trackList & resourceUrl
     */
    @GetMapping(value = "/master/getAlbumTracks", produces = MediaType.APPLICATION_JSON_VALUE)
    public AlbumTrackList getAlbumTracks(@RequestParam(required = false) String releaseTitle, @RequestParam(required = false) String artistName) {
        return informationService.getMasterAlbumTracks(releaseTitle, artistName);
    }
}
