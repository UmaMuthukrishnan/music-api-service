package com.discogs.info.response;

import com.discogs.info.model.Track;
import lombok.*;

import java.util.List;

/**
 * AlbumTrackResponse Model class
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AlbumTrackResponse {
    private String title;
    private List<Track> trackList;
    private String resourceUrl;
}
