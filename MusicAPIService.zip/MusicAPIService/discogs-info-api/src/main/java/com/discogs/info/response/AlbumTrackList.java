package com.discogs.info.response;

import lombok.*;

import java.util.List;

/**
 * AlbumTrackList Model class
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AlbumTrackList {
    private List<AlbumTrackResponse> albumTrackResponseList;
}
