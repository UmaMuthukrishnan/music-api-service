package com.discogs.info.service;

import com.discogs.info.exception.JsonOperationException;
import com.discogs.info.model.DiscogsInfoError;
import com.discogs.info.model.Track;
import com.discogs.info.response.AlbumTrackResponse;
import com.discogs.info.response.AlbumTrackList;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * DiscogsInformationService - Service class which calls a third part service DiscogsAPI
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */

@Slf4j
@Service
public class DiscogsInformationService {
    private static final String JSON_OPERATION_ERROR_CODE = "DISCOGS_JSON_ERROR";
    private static final String JSON_OPERATION_ERROR_DESC = "CANNOT READ JSON FILE";
    private static final String MASTER_RESOURCE_TYPE = "master";
    @Value("${discogsService.url}")
    private String url;
    @Value("${discogsService.key}")
    private String key;
    @Value("${discogsService.secret}")
    private String secret;

    private final ObjectMapper objectMapper;

    @Autowired
    public DiscogsInformationService(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    /**
     * Main method to retrieve tracks of Master Releases
     * from third party service : DiscogsAPIApplication
     * based on below parameters
     *
     * @param releaseTitle albumName
     * @param artist       artist name
     * @return AlbumTrackList which holds information about {title,trackList & resourceUrl}
     */

    public AlbumTrackList getMasterAlbumTracks(String releaseTitle, String artist) {
        //Retrieves DiscogsAPI response of Master releases based on given filters
        String discogsApiResponse = getDiscogsAPIResponse(releaseTitle, artist);
        //Retrieves resource_urls  of Master releases from the discogsApiResponse
        List<String> masterResourceList = getMasterResourceList(discogsApiResponse);
        //Retrieves the track list with album details from the filtered resource_url list
        List<AlbumTrackResponse> albumTrackList = getAlbumTrackResponseList(masterResourceList);
        //Returns the AlbumTrackList
        return AlbumTrackList.builder().albumTrackResponseList(albumTrackList).build();

    }

    /**
     * Gives the resource_url list from the filtered list based on type
     *
     * @param responseList Filtered list based on given type
     * @return list of resource_urls
     */
    private List<String> getMasterResourceList(String responseList) {
        List<String> resource_urlList = new ArrayList<>();
        JsonNode root;
        try {
            root = objectMapper.readTree(responseList);
        } catch (JsonProcessingException e) {
            throw new JsonOperationException(new DiscogsInfoError(JSON_OPERATION_ERROR_CODE,
                    JSON_OPERATION_ERROR_DESC, HttpStatus.INTERNAL_SERVER_ERROR),
                    "Error Reading JSON");
        }
        JsonNode results = root.get("results");

        results.forEach(result -> {
            String resource_url = result.get("resource_url").textValue();
            resource_urlList.add(resource_url);
        });
        return resource_urlList;

    }

    /**
     * Gives the track list with album details from the filtered resource_url list
     * Loop through each resource_url to get the album details by making a Webclient call
     *
     * @param masterResourceList filtered resource_url lists based on given type from user input
     * @return list of AlbumTrackResponse
     */
    private List<AlbumTrackResponse> getAlbumTrackResponseList(List<String> masterResourceList) {
        List<AlbumTrackResponse> albumTrackResponseList = Collections.emptyList();
        List<String> resourceResponseList = new ArrayList<>();
        //Looping through each resource_url to get the details
        masterResourceList.forEach(resource -> resourceResponseList.add(getResourceAPIResponse(resource)));
        if (resourceResponseList.size() > 0) {
            albumTrackResponseList = getAlbumTrackList(resourceResponseList);
        }
        return albumTrackResponseList;
    }

    /**
     * Gives the List of Album track details i.e.,{title,trackList,resource_url}
     *
     * @param resourceResponseList Filtered resource_url response lists
     * @return list of AlbumTrackResponse
     */
    private List<AlbumTrackResponse> getAlbumTrackList(List<String> resourceResponseList) {
        List<AlbumTrackResponse> albumTrackResponseList = new ArrayList<>();
        if (resourceResponseList != null && resourceResponseList.size() > 0) {
            resourceResponseList.forEach(resource -> {
                JsonNode root;
                try {
                    root = objectMapper.readTree(resource);
                } catch (JsonProcessingException e) {
                    throw new JsonOperationException(new DiscogsInfoError(JSON_OPERATION_ERROR_CODE,
                            JSON_OPERATION_ERROR_DESC, HttpStatus.INTERNAL_SERVER_ERROR),
                            "Error Reading JSON");
                }
                if (root != null) {
                    JsonNode trackList = root.get("tracklist");
                    String resource_url = root.get("resource_url").textValue();
                    String title = root.get("title").textValue();
                    List<Track> listOfTracks = getTrackDetails(trackList);
                    albumTrackResponseList.add(AlbumTrackResponse.builder()
                            .title(title).resourceUrl(resource_url).trackList(listOfTracks).build());
                }
            });
        }
        return albumTrackResponseList;
    }

    /**
     * Method to retrieve list of tracks for the given resource_url
     *
     * @param trackList JsonNode with trackList details
     * @return list of Track object {trackNumber,trackTitle}
     */
    private List<Track> getTrackDetails(JsonNode trackList) {

        List<Track> tracks = new ArrayList<>();
        if (trackList != null && trackList.isArray()) {

            trackList.forEach(track -> {
                String trackNumberValue = track.get("position").textValue();
                String trackTileValue = track.get("title").textValue();
                tracks.add(Track.builder()
                        .trackNumber(trackNumberValue)
                        .trackTitle(trackTileValue)
                        .build());
            });
        }
        return tracks;
    }


    /**
     * Method to retrieve the DiscogsAPI response only for Master releases using Webclient call
     *
     * @param releaseTitle given albumName
     * @param artist       given artistName
     * @return String as a response
     */
    private String getDiscogsAPIResponse(String releaseTitle, String artist) {
        return WebClient.builder().baseUrl(url).build()
                .get()
                .uri(uriBuilder -> uriBuilder
                        .queryParam("release_title", releaseTitle)
                        .queryParam("artist", artist)
                        .queryParam("type", MASTER_RESOURCE_TYPE)
                        .queryParam("key", key)
                        .queryParam("secret", secret)
                        .build())
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .accept(MediaType.APPLICATION_JSON)
                .acceptCharset(StandardCharsets.UTF_8)
                .retrieve()
                .bodyToMono(String.class)
                .block();
    }

    /**
     * Method to retrieve the resource_url response using Webclient call
     *
     * @param url resource_url
     * @return response of resource_url as a String
     */
    private String getResourceAPIResponse(String url) {
        return WebClient.builder().baseUrl(url).build()
                .get()
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .retrieve()
                .bodyToMono(String.class)
                .block();
    }


}
