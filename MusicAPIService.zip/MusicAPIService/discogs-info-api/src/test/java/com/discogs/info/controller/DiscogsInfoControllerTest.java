package com.discogs.info.controller;

import com.discogs.info.config.ApplicationTestConfig;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import java.util.Collections;

import static org.hamcrest.Matchers.notNullValue;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

/**
 * Unit Testcase Class for DiscogsInfoController
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(
        classes = {ApplicationTestConfig.class})
@WebAppConfiguration
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
public class DiscogsInfoControllerTest {

    @Autowired
    private WebApplicationContext webApplicationContext;

    public MockMvc mockMvc;

    @Before
    public void setUp() {

        this.mockMvc = webAppContextSetup(webApplicationContext).build();

    }

    /**
     * Rest API Method to validate response from DiscogsAPI
     * with valid parameters of releaseTitle & artistName
     */
    @Test
    public void testToGetMasterAlbumTracks_withValidParameters() throws Exception {
        mockMvc.perform(get("/discogsInfo/master/getAlbumTracks")
                .param("releaseTitle", "nevermind")
                .param("artistName", "nirvana")
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$.albumTrackResponseList", notNullValue()))
                .andExpect(jsonPath("$.albumTrackResponseList[0].title", is("Nevermind")))
                .andExpect(jsonPath("$.albumTrackResponseList[0].trackList", notNullValue()))
                .andExpect(jsonPath("$.albumTrackResponseList[0].trackList[0]", notNullValue()));
    }

    /**
     * RestApi Method to validate whether empty list is getting returned with
     * incorrect values of releaseTitle & artistName
     */
    @Test
    public void testToGetMasterAlbumTracks_withInValidParameters() throws Exception {
        mockMvc.perform(get("/discogsInfo/master/getAlbumTracks")
                .param("releaseTitle", "abc")
                .param("artistName", "1235")
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$.albumTrackResponseList", notNullValue()))
                .andExpect(jsonPath("$.albumTrackResponseList", is(Collections.EMPTY_LIST)));
    }
}
