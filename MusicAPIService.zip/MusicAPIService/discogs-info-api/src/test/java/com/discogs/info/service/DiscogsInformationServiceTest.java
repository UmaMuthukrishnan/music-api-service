package com.discogs.info.service;

import com.discogs.info.config.ApplicationTestConfig;
import com.discogs.info.model.Track;
import com.discogs.info.response.AlbumTrackList;
import com.discogs.info.response.AlbumTrackResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;


import java.util.List;

/**
 * DiscogsInformationServiceTest class
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */

@RunWith(SpringRunner.class)
@ContextConfiguration(
        classes = {ApplicationTestConfig.class})
@WebAppConfiguration
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
@SpringBootTest(classes = {DiscogsInformationService.class})
public class DiscogsInformationServiceTest {

    @Autowired
    DiscogsInformationService discogsInformationService;

    /**
     * Method to validate response from DiscogsAPI
     * with valid parameters of releaseTitle & artistName
     */
    @Test
    public void testToGetValidAlbumTrackList() {

        AlbumTrackList albumTrackList = discogsInformationService.getMasterAlbumTracks("nevermind", "nirvana");
        List<AlbumTrackResponse> albumTrackResponses = albumTrackList.getAlbumTrackResponseList();
        AlbumTrackResponse albumTrackResponse = albumTrackResponses.get(0);
        String title = albumTrackResponse.getTitle();
        List<Track> tracks = albumTrackResponse.getTrackList();
        String resourceUrl = albumTrackResponse.getResourceUrl();
        boolean hasTitle = title.toLowerCase().contains("nevermind");
        Assert.assertNotNull(albumTrackList);
        Assert.assertTrue(albumTrackResponses.size() > 0);
        Assert.assertTrue(hasTitle);
        Assert.assertTrue(tracks.size() > 0);
        Assert.assertNotNull(resourceUrl);
    }

    /**
     * Method to validate whether empty list is getting returned with
     * incorrect values of releaseTitle & artistName
     */
    @Test
    public void testToGetInValidAlbumTrackList() {
        AlbumTrackList albumTrackList = discogsInformationService.getMasterAlbumTracks("abc", "123");
        List<AlbumTrackResponse> albumTrackResponses = albumTrackList.getAlbumTrackResponseList();
        Assert.assertTrue(albumTrackResponses.isEmpty());
    }
}
