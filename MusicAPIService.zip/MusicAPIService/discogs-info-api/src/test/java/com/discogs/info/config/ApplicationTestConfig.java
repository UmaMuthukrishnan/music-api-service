package com.discogs.info.config;

import com.discogs.info.controller.DiscogsInfoController;
import com.discogs.info.service.DiscogsInformationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@ComponentScan("com.discogs.info")
@ActiveProfiles("test")
@PropertySource("classpath:application.properties")
@EnableWebMvc
public class ApplicationTestConfig implements WebMvcConfigurer {
}
