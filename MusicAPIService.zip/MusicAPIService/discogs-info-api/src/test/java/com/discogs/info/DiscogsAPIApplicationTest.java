package com.discogs.info;

import com.discogs.info.controller.DiscogsInfoControllerTest;
import com.discogs.info.service.DiscogsInformationServiceTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Common class to run all the test cases in DiscogsInfoControllerTest.class, DiscogsInformationServiceTest.class
 *
 * @author Uma Muthukrishnan
 * @version 1.0
 */

//@RunWith(Suite.class)
//@Suite.SuiteClasses({DiscogsInfoControllerTest.class, DiscogsInformationServiceTest.class})
public class DiscogsAPIApplicationTest {
}
