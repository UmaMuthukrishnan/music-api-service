## Technical stack requirements
Maven,
JDK 8,
Spring Boot 2.2.6

Approach: I have implemented microservices architecture here.

This Service is to get details from the thid-party service DiscogsAPI.

##About : Discogs Info service
 Microservices Architecture is used in designing Discogs Info service.
 
 The discogs-info-api service (aka) producer ,provides data to the music-provider-service.
 
 This interacts with another third party service namely Discogs-API,to get details about the artist's album data.
 It uses basic user authentication for consuming the Discogs-API.
 
 (OAuth is a good option to securely accessing the above API ,but I haven't implemented it due to time constraints.)
 
 Both the music-provider-api and discogs-info-api services are registered in Eureka naming server.Eureka,acts as a discovery
 server,so that the services can be used in other services with the name tagged to Eureka,rather than defining a name and port.
  
## Steps to be followed for accessing endpoints.

1. Start Eureka Discovery Server (Runs on port 8761)
2. Start discogs-info-api service (Runs on port 8090)
3. Start music-provider-api service (Runs on port 8080)


All the above mentioned services are dockerized. Use docker-compose.yml file for running the application in docker.

#####Note: Enable annotation-processing option in IDE while running maven build, as JPA specifications are used in creating the testcases.

##Accessing RestAPI endpoints
 Created DiscogsInfoController for artist (/artists endpoint to manage Artist data)
      
        GET /discogsInfo/master/getAlbumTracks to retrieve more details about an individual album using a 3rd party service
                      -Accepts ArtistName && AlbumName
                      - Implemented a search to get only the master releases
                       -Method will return track listing using the resource_url(s) of the found album.
                       -WebClient to interact with the API calls instead of RestTemplate        
 