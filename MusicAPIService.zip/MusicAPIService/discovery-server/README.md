##Discovery Server for MusicAPI service
 Microservices Architecture is used in designing MusicAPI service.
 
 There are two services namely music-provider-api and discogs-info-api are involved here.
 
 The music-provider-api (aka) consumer ,which consumes the discogs-info-api for providing
 more details about the artist's album details.
 
 The discogs-info-api service (aka) producer ,provides data to the music-provider-service.
 
 This interacts with another third party service namely Discogs-API,to get details about the artist's album data.
 It uses basic user authentication for consuming the Discogs-API.
 
 (OAuth is a good option to securely accessing the above API ,but I haven't implemented it due to time constraints.)
 
 Both the music-provider-api and discogs-info-api services are registered in Eureka naming server.Eureka,acts as a discovery
 server,so that the services can be used in other services with the name tagged to Eureka,rather than defining a name and port.
 
 
## Steps to be followed for accessing endpoints.

1. Start Eureka Discovery Server
2. Start discogs-info-api service
3. Start music-provider-api service


All the above mentioned services are dockerized. Use docker-compose.yml file for running the application in docker.

Note: Enable annotation-processing option in IDE while running maven build, as JPA specifications are used in creating the testcases.