package com.music;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * Discovery Server for MusicApiApplication
 * <p>
 * Main class for MusicDiscoveryServerApplication
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */

@SpringBootApplication
@EnableEurekaServer
public class MusicDiscoveryServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(MusicDiscoveryServerApplication.class, args);
    }
}
